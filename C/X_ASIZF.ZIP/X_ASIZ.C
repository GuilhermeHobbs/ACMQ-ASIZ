/*
Versao C do programa ASIZ
*****************************************************************************
Analise de circuitos a corrente chaveada em transformada Z - Versao XView-PC
Antonio Carlos Moreirao de Queiroz - COPPE/DEEL-UFRJ - 1992
V. 1.0  - Traducao para C da versao 1/2c em Pascal
V. 1.0a - 30/8/94: Introduzida variavel reffases
V. 1.1  - 26/10/94: Calculo do espectro da saida, comando X, arq. para grn
V. 1.1a - 02/01/95: Mudados deta e detb, uso de da e db, e elim. denominador
V. 1.1b - 25/01/95: Melhorado tratamento numerico da VCVS
V. 1.1c - 29/01/95: Alocados melhor os numeradores. Corrigida normalizacao.
V. 1.2  - 04/11/95: Preparando atualizacao com versao Sun 1.3a.
                    Tentando adaptar para djgpp V2
                    Exige fim de arquivo na ultima linha do netlist?
                    Parece ok em 21/7/98.
V. 1.2a - 17/07/02: Lista limites.
Obs:
A otimizacao I provoca erro no calculo de raizes. A deflacao nao funciona
porque Rmult nao recebe parametros indexados (?!)
*****************************************************************************
*/

#include <string.h>
#include <dos.h>
#ifdef __GNUC__
#include <gppconio.h>
#include <libbcc.h>
#include <DPMI.h>
#define coreleft _go32_dpmi_remaining_virtual_memory
#endif
#ifdef __TURBOC__
#include <conio.h>
#include <alloc.h>
#endif
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <assert.h>
#include <dir.h>
#include <time.h>
#include "mickey.h"
#include "xview.h"
#include "lu.h"
#include "extkeys.h"
#include "xv_var.h"
#ifdef __TURBOC__
#define versao          "1.2a of 04/11/2002"
#define fftmax          32 /*Maximo grau para FFT*/
#define nosmax          200 /*Maximo n�mero de nos*/
#define elmax           400 /*Numero maximo de elementos, exclusive chaves*/
#endif
#ifdef __GNUC__
#define versao          "1.2a of 04/11/2002 (djgpp)"
#define fftmax          64 /*Maximo grau para FFT*/
#define nosmax          400 /*Maximo n�mero de nos*/
#define elmax           2000 /*Numero maximo de elementos, exclusive chaves*/
#endif
#define graumax         (fftmax-1) /*Grau maximo dos polinomios em z*/
#define grandemax       (fftmax*fasmax-1) /*Idem, dos polinomios em z^1/fases*/
#define cm              15 /*Campo numerico real*/
#define dc              9 /*Decimais de real*/
#define tamnome         5 /*Tamanho dos nomes dos elementos*/
#define intnome         (tamnome+3) /*Tamanho dos nomes internos*/
#define sg              ".sgr"
#define c_cursor LIGHTRED

#ifdef __TURBOC__
extern unsigned _stklen=40000u; /*Tamanho da stack*/
#endif
#ifdef __GNUC__
extern int _stklen=64000;
#endif

typedef enum {
  resistor,chave,fonteI,fonteV,capacitor,amplificador,VCCS,VCVS
} elemento;
typedef double coefgrande[grandemax+1];

typedef struct polpequeno {
  double *cre, *cim;
  short g,minpot;
  double vala,valb;
  boolean valido;
} polpequeno;

typedef struct polgrande {
  coefgrande cf;
  short g;
} polgrande;

typedef struct raizes {
  double re[grandemax],im[grandemax];
  short g;
  boolean calculados;
} raizes;

typedef short apontadores[fasmax][nosmax+1];
typedef polpequeno numfases[fasmax];
typedef polpequeno *numeradores[linmax];
typedef boolean identificador[linmax+1];
typedef enum {
  frequencia,transiente,mensagens
} tipotabela;

typedef struct _REC_NetList {
  char nome[intnome+1];
  short n1,n2;
  boolean selecionado;
  char grupo;
  elemento tipo;
  union {
    double Res;
    double Is;
    struct {
      short nox;
      double Vs;
    } U3;
    short fase;
    double Cap;
    short nout;
    struct {
      short n3,n4;
      double Gm;
    } U6;
    struct {
      short noxc,n3c,n4c;
      double Av;
    } U7;
  } UU;
} _REC_NetList;

/*Variaveis dos graficos*/

#define refmax          4
#define segmax          400
#define xmin            40
#define ymin            18

typedef double grafico[segmax+1];

typedef struct tiporeffreq {
  polgrande Rnglobal; /*Numerador da referencia*/
  polpequeno Rden; /*Denominador da referencia*/
  boolean reffreqreter; /*S/H na referencia*/
  short reffases; /*Numero de fases*/
  grafico Rgan; /*Modulo e fase da referencia*/
  grafico Rang;
} tiporeffreq;

typedef struct tiporeftran {
  short ultimotran; /*Ultimo ponto da referencia transiente*/
  boolean reftranreter; /*S/H na referencia*/
  grafico RVo;
} tiporeftran;

typedef short cores[7];

char grupoatual='*';
/*Estado do programa*/
boolean netlist_valido=FALSE,analise_valida=FALSE,
	       polos_validos=FALSE,zeros_validos=FALSE,
	       frequencia_valida=FALSE,desvios_validos=FALSE,
	       transiente_valido=FALSE,
               reter_imagem=FALSE;
/*Interface*/
Xv_opaque menu1,menuplot,menumsg,jterminal,ttymsg,jfrequencia,
		 cfrequencia,jraizes,craizes,jtransiente,ctransiente,
		 jnetlist,tnetlist,tfases,bread,jpanalise,tnsaida,
		 traio,tdisp,tminimo,tgrau,ssh,tfs,banalisar,jpraizes,
		 ttolz,ttolp,treal,timag,tremin,timmin,tdelta,bplot,
		 blist,jpfrequencia,twmin,twmax,tgmin,tgmax,slog,
		 srads,tsegmf,brf,jptransiente,stinput,brt,tfase,
		 tfreq,tampl,sinput,tsegmt,tvmax,tvmin,jsensi,ssensi,
		 sdesvios,tvar,brsensi,bwsensi,csensi,jpnumerador,
		 tsaida,stiponum,tfk,tfj,sadjunto,blistnum,jrelatorio,
		 trelatorio,brelatorio,jdiretorio,cdiretorio,tmask,jmos,
		 scap,tcgs,tcgd,sgds,tgds,
                 jpespectro,tsp,bpsp,blsp;

short placa,modo; /*Modo grafico*/
short i,j,k; /*Uso geral*/
long mm; /*Usado para medicoes de memoria*/
boolean ok;
char txt[256];
char ch;
short nos,elementos,fases; /*Dimensoes do circuito*/
short fasesatual; /*Fases do circuito atual*/
short variaveis; /*Numero de variaveis calculadas*/
double z1f,z2f,z1,z2; /*z^(1/f), z*/
double w; /*frequencia atual em rads/s*/
short equacoes; /*Equacoes no sistema final*/
short e; /*Contador de elementos*/
short jmin,jmax,kmin,kmax; /*Limites das fases no numerador*/
char rede[256]; /*Nome da rede*/
FILE *arquivo; /*E/S*/
short graufft; /*Grau da FFT*/
short ordemfft; /*Ordem da FFT*/
double Ncte; /*Cte multiplicativa do denominador*/
short capacitivas; /*Numero de equacoes capacitivas*/
polpequeno Nden; /*Denominador*/
numeradores Npa; /*Numeradores da rede normal*/
numeradores Apa; /*Numeradores da rede adjunta*/
polgrande Nglobal; /*Numerador global*/
short reffreq; /*Numero de referencias na resposta em frequencia*/
short reftran; /*Numero de referencia na resposta transiente*/
boolean relatorio; /*Se existe relatorio aberto*/
boolean plotarfase; /*Se a fase deve ser plotada*/
short maxz; /*Maxima potencia de z^1/f*/
short npl; /*Nomes por linha na janela de p. sensibilidade*/
raizes Polos,Zeros; /*Polos e zeros*/
apontadores C,L; /*Apontador de colunas/linhas*/
identificador Eqcap; /*Se as equacoes/linhas sao capacitivas*/
boolean normal; /*Modo de inclusao de Ggs e capacitores*/
tipotabela asalvar; /*O que deve ser salvo no relatorio*/
short total,nomes; /*Usado na selecao de arquivo*/
_REC_NetList NetList[elmax];
short ioresult;
unsigned int sizepoly=0, sizenum=0; /*Tamanhos dos polinomios*/
short fasesantes, equacoesantes;; /*Dados da ultima analise feita*/

char unid[2][5]={
  "rd/s","Hz"
};

boolean grade=TRUE;

cores cor={
  0,15,YELLOW,LIGHTGRAY,GREEN,BLUE,RED};

cores cormono={
  0,1,1,1,1,1,1
};

/*Resposta em Frequencia*/
double *Frq,*Gan,*Ang,*Dgan,*Dang; /*Valores do grafico*/
tiporeffreq *Reff[refmax];
short yfmax,xfmax; /*Limites*/
short ultimof,hf; /*Ultimo ponto e ponto atual*/
short fcsr,colcsr; /*Cursor*/
double ah,bh,aw,bw,ag,bg,af,bf; /*Mapeamento*/
boolean plotardesvios; /*Calcular desvios*/
/*Polos e zeros*/
double ay,by,ax,bx,fator; /*Mapeamento*/
short rcsr,xcursor,ycursor; /*Cursor*/
short xrmax,yrmax; /*Limites*/
short xasp,yasp; /*Aspecto*/
/*Resposta transiente*/
double *Tempo,*Vi,*Vo; /*Valores nos graficos*/
tiporeftran *Reft[refmax];
short xtmax,ytmax; /*Limites*/
short ultimot,ht; /*Ultimo ponto e ponto atual*/
double av,bv,at,bt; /*Mapeamento*/
short tcsr,ctcsr; /*Cursor*/

short pos(char c, char* str2)
{
   char* res;
   res=strchr(str2,c);
   if (res==NULL) return 0;
   else return res-str2+1;
}

double Ex(double x,double t)
{
  return exp(t*log(x));
}

void Saida(char *x)
{
  char STR1[256];

  sprintf(STR1,"%s\n",x);
  ttysw_output(ttymsg,STR1);
}

boolean AnaliseValida(void)
{
  boolean Result;

  Result=analise_valida;
  if (!analise_valida)
    Saida("* No analysis made");
  return Result;
}

boolean Estatistico(void)
{
  return(sdesvios->v.ssetting.sel_setting==1);
}

boolean Adjunto(void)
{
  return(sadjunto->v.ssetting.sel_setting==2);
}

boolean Log(void)
{
  return(slog->v.ssetting.sel_setting==1);
}

boolean Hertz(void)
{
  return(srads->v.ssetting.sel_setting==2);
}

void ErroFatal(char *texto)
{
  char STR2[256];

  sprintf(STR2,"\n* Error: %s\n\nTouch any key to interrupt...",texto);
  Saida(STR2);
  ch=getch();
  if (relatorio) fclose(arquivo);
  restorecrtmode();
  exit(1);
}

char *NomeAtual(char *Result)
{
  sprintf(txt,"N(%d",tsaida->v.stextfield.panel_int);
  if (stiponum->v.ssetting.sel_setting==1)
  sprintf(txt+strlen(txt),",%d,%d",
    tfk->v.stextfield.panel_int,
    tfj->v.stextfield.panel_int);
  strcat(txt,")");
  if (Adjunto())
  strcat(txt,"^");
  if (tsaida->v.stextfield.panel_int>nos)
    strcat(txt,"(aux)");
  return strcpy(Result,txt);
}

/* variables for AnalisarNoCirculo: */
struct LOC_AnalisarNoCirculo {
  double w; /*Angulo atual de Z*/
  double t; /*Expoentes*/
  double r; /*Exponenciais do raio*/
  short x; /*Ponto atual no circulo*/
  short conj; /*Ponto complexo conjugado*/
} ;

/* variables for MontarSistema: */
struct LOC_MontarSistema {
  struct LOC_AnalisarNoCirculo *LINK;
  short l1,l2,c1,c2;
} ;

void Transcondutancia(short na,short nb,short nc,short nd,short f1,
			    short f2,double g1,double g2,
			    struct LOC_MontarSistema *LINK)
{
  LINK->l1=L[f1-1][na];
  LINK->l2=L[f1-1][nb];
  LINK->c1=C[f2-1][nc];
  LINK->c2=C[f2-1][nd];
  if (normal||Eqcap[LINK->l1]) {
      Y1[LINK->l1][LINK->c1]+=g1;
      Y1[LINK->l1][LINK->c2]-=g1;
      Y2[LINK->l1][LINK->c1]+=g2;
      Y2[LINK->l1][LINK->c2]-=g2;
  }
  if (!(normal||Eqcap[LINK->l2]))
    return;
  Y1[LINK->l2][LINK->c2]+=g1;
  Y1[LINK->l2][LINK->c1]-=g1;
  Y2[LINK->l2][LINK->c2]+=g2;
  Y2[LINK->l2][LINK->c1]-=g2;
}

void MontarSistema(struct LOC_AnalisarNoCirculo *LINK)
{
  struct LOC_MontarSistema V;
  _REC_NetList *WITH;
  double t;

  V.LINK=LINK;
  for (i=0; i<=equacoes; i++) {
      for (j=0; j<=equacoes; j++) {
	  Y1[i][j]=0.0;
	  Y2[i][j]=0.0;
      }
      for (j=1; j<=fases; j++) {
	  E1[i][j]=0.0;
	  E2[i][j]=0.0;
	  A1[i][j]=0.0;
	  A2[i][j]=0.0;
      }
  }
  for (i=1; i<=fases; i++) {
      A1[C[i-1][tnsaida->v.stextfield.panel_int]][i]=-z1f;
      A2[C[i-1][tnsaida->v.stextfield.panel_int]][i]=-z2f;
  }
  for (e=1; e<=elementos; e++) {
      WITH=&NetList[e-1];
      switch (WITH->tipo) {

	case fonteV:
	  for (i=1; i<=fases; i++) {
	      V.l1=L[i-1][WITH->UU.U3.nox];
	      E1[V.l1][i]-=WITH->UU.U3.Vs;
	      Y1[V.l1][C[i-1][WITH->n1]]-=1;
	      Y1[V.l1][C[i-1][WITH->n2]]+=1;
	  }
	  break;

	case VCVS:
	  t=1/WITH->UU.U7.Av;
	  for (i=1; i<=fases; i++) {
	      V.l1=L[i-1][WITH->UU.U7.noxc];
	      Y1[V.l1][C[i-1][WITH->n1]]-=t;
	      Y1[V.l1][C[i-1][WITH->n2]]+=t;
	      Y1[V.l1][C[i-1][WITH->UU.U7.n3c]]+=1;
	      Y1[V.l1][C[i-1][WITH->UU.U7.n4c]]-=1;
	  }
	  break;

	case VCCS:
	  for (i=1; i<=fases; i++)
	    Transcondutancia(WITH->n1,WITH->n2,WITH->UU.U6.n3,WITH->UU.U6.n4,
			     i,i,WITH->UU.U6.Gm,0.0,&V);
	  break;

        case resistor:
          for (i=1; i<=fases; i++)
            Transcondutancia(WITH->n1,WITH->n2,WITH->n1,WITH->n2,i,i,
                             1/WITH->UU.Res,0.0,&V);
          break;

        case capacitor:
          for (i=1; i<=fases; i++) {
              normal=FALSE;
 /*Os termos abaixo so devem entrar em eqs. capacitivas*/
 /*O primeiro e sempre multiplicado por z*/
 /*e o segundo nunca*/
              Transcondutancia(WITH->n1,WITH->n2,WITH->n1,WITH->n2,i,i,
                               WITH->UU.Cap*z1f,WITH->UU.Cap*z2f,&V);
	      Transcondutancia(WITH->n1,WITH->n2,WITH->n1,WITH->n2,i%fases+1,
                               i,-WITH->UU.Cap,0.0,&V);
              normal=TRUE;
          }
          break;

        case fonteI:
	  for (i=1; i<=fases; i++) {
              V.l1=L[i-1][WITH->n1];
              V.l2=L[i-1][WITH->n2];
              E1[V.l1][i]-=WITH->UU.Is;
              E1[V.l2][i]+=WITH->UU.Is;
          }
          break;

        default:
          ErroFatal("Something is wrong");
          break;
      }
  }
}

void GuardarDenominador(struct LOC_AnalisarNoCirculo *LINK)
{
  double DUMMY;

 /*Correcao para o denominador*/
  LINK->t=modf((double)maxz/fases,&DUMMY);
  if (LINK->t!=0) {
      LINK->t=1-LINK->t;
      LINK->r=Ex(traio->v.stextfield.panel_real,LINK->t);
      deta=Rmult(deta,detb,LINK->r*cos(LINK->w*LINK->t),
                 LINK->r*sin(LINK->w*LINK->t));
      detb=Ires;
  }
  LINK->conj=(graufft-LINK->x)%graufft;
  Nden.cre[LINK->x]=deta;
  Nden.cim[LINK->x]=detb;
  Nden.cre[LINK->conj]=deta;
  Nden.cim[LINK->conj]=-detb;
  Nden.minpot=0;
}

void GuardarNumeradores(double **S1,double **S2,polpequeno **Num,
                              short (*Q)[nosmax+1],short *Qx,boolean adjunto,
                              struct LOC_AnalisarNoCirculo *LINK)
{
  short f;
  double na,nb;
  polpequeno *WITH;

  for (i=1; i<=equacoes; i++) {
      for (j=1; j<=fases; j++) {
          na=Rmult(S1[Qx[i]][j],S2[Qx[i]][j],deta,detb);
          nb=Ires;
 /*Corre��o para os numeradores*/
 /*� necess�rio descobrir a que fase f i pertence*/
 /*Isto poderia ser feito uma s� vez*/
          f=0;
          do {
              f++;
              k=0;
              do {
                  k++;
                  ok=(k<=variaveis&&Q[f-1][k]==i);
              } while (!(ok||k>variaveis));
          } while (!ok);
          if (adjunto) {
              k=-((f-j+fases)%fases); /*Importante detalhe*/
	  }
	  else {
	      k=-((j-f+fases)%fases);
	  }
          if (f!=j) {
	      LINK->t=(double)k/fases;
	      LINK->r=Ex(traio->v.stextfield.panel_real,LINK->t);
              na=Rmult(na,nb,LINK->r*cos(LINK->w*LINK->t),
                         LINK->r*sin(LINK->w*LINK->t));
              nb=Ires;
          }
 /*Corre��o para numeradores do sistema adjunto
   em linhas n�o capacitivas, n�o multiplicadas*/
          if (adjunto&&!Eqcap[i]) {
              na=Rdiv(na,nb,z1f,z2f);
              nb=Ires;
          }
          WITH=&Num[i-1][j-1];
          WITH->cre[LINK->x]=na;
          WITH->cim[LINK->x]=nb;
          WITH->cre[LINK->conj]=na;
          WITH->cim[LINK->conj]=-nb;
          WITH->minpot=-k;
      }
  }
}

void NaoDa(void) {
  ErroFatal("Not enough memory");
}

void AnalisarNoCirculo(void)
{
  struct LOC_AnalisarNoCirculo V;
  indice Ax,Nx; /*Para lembrar onde estao as variaveis*/
  short FORLIM;
  char STR2[256],STR3[256];

  for (i=0; i<=equacoes; i++)
    Nx[i]=i;
  graufft=1;
  ordemfft=0;
  while (graufft<=tgrau->v.stextfield.panel_int) {
      graufft*=2;
      ordemfft++;
  }
  sprintf(STR2,"Interpolation degree (in z): %hd",graufft);
  Saida(STR2);
  if (graufft>fftmax) {
      sprintf(STR2,"The maximum degree is %hd",graumax);
      ErroFatal(STR2);
  }
  /*Realocacao das tensoes nodais*/
  if (sizenum!=0) {
    for (i=equacoesantes-1; i>=0; i--) {
      for (j=fasesantes-1; j>=0; j--) {
	free(Apa[i][j].cim);
	free(Apa[i][j].cre);
	free(Npa[i][j].cim);
	free(Npa[i][j].cre);
      }
      free(Apa[i]);
      free(Npa[i]);
    }
    free(Nden.cim);
    free(Nden.cre);
  }
  sizepoly=(graufft+1)*sizeof(double);
  sizenum=fases*sizeof(polpequeno);
  fasesantes=fases;
  equacoesantes=equacoes;
  if ((Nden.cre=(double*)malloc(sizepoly))==0)  NaoDa();
  if ((Nden.cim=(double*)malloc(sizepoly))==0)  NaoDa();
  for (i=0; i<equacoes; i++) {
    if ((Npa[i]=(polpequeno*)malloc(sizenum))==0) NaoDa();
    if ((Apa[i]=(polpequeno*)malloc(sizenum))==0) NaoDa();
    for (j=0; j<fases; j++) {
      if ((Npa[i][j].cre=(double*)malloc(sizepoly))==0) NaoDa();
      if ((Npa[i][j].cim=(double*)malloc(sizepoly))==0) NaoDa();
      if ((Apa[i][j].cre=(double*)malloc(sizepoly))==0) NaoDa();
      if ((Apa[i][j].cim=(double*)malloc(sizepoly))==0) NaoDa();
    }
  }
  if (!AlocarSistema(equacoes,fases)) {
      ErroFatal("Not enough memory for the system of equations");
      return;
  }
  ttysw_output(ttymsg,"Analyzing...");
  FORLIM=graufft/2;
  for (V.x=0; V.x<=FORLIM; V.x++) {
      memcpy(Ax,Nx,sizeof(indice));
      sprintf(STR3,"%hd ",graufft/2-V.x);
      ttysw_output(ttymsg,STR3);
      V.w=2*M_PI/graufft*V.x;
      V.r=Ex(traio->v.stextfield.panel_real,1.0/fases);
      z1f=V.r*cos(V.w/fases);
      z2f=V.r*sin(V.w/fases);
      MontarSistema(&V);
      if (!ResolverSistema(Ax,tminimo->v.stextfield.panel_real))
        ErroFatal("System determinant too small");
      GuardarDenominador(&V);
      GuardarNumeradores(E1,E2,Npa,C,Nx,FALSE,&V);
      GuardarNumeradores(A1,A2,Apa,L,Ax,TRUE,&V);
  }
  ttysw_output(ttymsg,"\n");
  DesalocarSistema();
}

/* variables for FFT: */
struct LOC_FFT {
  short n;
} ;

short Inverso(short x,struct LOC_FFT *LINK)
{
  short i,u;

  u=0;
  i=((unsigned)LINK->n)>>1;
  do {
      if (x&1)
        u+=i;
      i=((unsigned)i)>>1;
      x=((unsigned)x)>>1;
  } while (x!=0);
  return u;
}

void FFT(double *A,double *B,short n_,short m,boolean direto)
{
  struct LOC_FFT V;
  short k,k1,l,s,i,j,i1,i2,FORLIM;
  double x1,x2,y1,y2;

  V.n=n_;
  for (k=m-1; k>=0; k--) {
      k1=1<<k;
      l=0;
      do {
          s=Inverso(l/k1,&V);
          x1=cos(2*M_PI*s/V.n);
          y1=sin(2*M_PI*s/V.n);
          if (direto)
            y1=-y1;
          for (j=0; j<k1; j++) {
              i1=j+l+k1;
              i2=j+l;
              x2=A[i1]*x1-B[i1]*y1;
              y2=A[i1]*y1+B[i1]*x1;
              A[i2]+=x2;
              B[i2]+=y2;
              A[i1]=A[i2]-x2-x2;
              B[i1]=B[i2]-y2-y2;
          }
          l+=k1<<1;
      } while (l<V.n);
  }
  FORLIM=V.n;
  for (i=0; i<FORLIM; i++) {
      s=Inverso(i,&V);
      if (s>i) {
          x1=A[i];
          A[i]=A[s];
          A[s]=x1;
          x1=B[i];
          B[i]=B[s];
          B[s]=x1;
      }
  }
  if (!direto)
    return;
  FORLIM=V.n;
  for (i=0; i<FORLIM; i++) {
      A[i]/=V.n;
      B[i]/=V.n;
  }
}

void Normalizar(polpequeno *A,double *cte,boolean denominador)
{
  double maximo;
  short i,FORLIM;

  A->g=graufft-1;
  maximo=0.0;
  FORLIM=A->g;
  for (i=1; i<=FORLIM; i++)
    A->cre[i]/=exp(i*log(traio->v.stextfield.panel_real));
  for (i=0; i<=FORLIM; i++) {
      if (fabs(A->cre[i])>maximo)
        maximo=fabs(A->cre[i]);
  }
  maximo/=tdisp->v.stextfield.panel_real;
  for (i=0; i<=FORLIM; i++) {
      if (fabs(A->cre[i])<maximo)
        A->cre[i]=0.0;
  }
  while (A->cre[A->g]==0&&A->g>0)
    A->g--;
  if (denominador)
    *cte=A->cre[A->g];
  FORLIM=A->g;
  for (i=0; i<=FORLIM; i++)
    A->cre[i]/=*cte;
  if (fabs(A->cre[A->g])<tminimo->v.stextfield.panel_real) {
    A->g=0;
    A->cre[0]=0.0;
  }
}

void InterpolarNumeradores(polpequeno **Num,double *cte,char *n_a)
{
  char STR3[256];

  sprintf(STR3,"Interpolating the %hd numerators of the %s network",
	  equacoes*fases,n_a);
  ttysw_output(ttymsg,STR3);
  for (i=1; i<=equacoes; i++) {
      for (j=1; j<=fases; j++) {
          ttysw_output(ttymsg,".");
          FFT(Num[i-1][j-1].cre,Num[i-1][j-1].cim,graufft,ordemfft,TRUE);
          Normalizar(&Num[i-1][j-1],cte,FALSE);
      }
  }
  ttysw_output(ttymsg,"\n");
}

void InterpolarPolinomios(void)
{
  Saida("Interpolating the denominator");
  FFT(Nden.cre,Nden.cim,graufft,ordemfft,TRUE);
  Normalizar(&Nden,&Ncte,TRUE);
  InterpolarNumeradores(Npa,&Ncte,"normal");
  InterpolarNumeradores(Apa,&Ncte,"adjoint");
}

char *Expoente(char *Result,short n,short d)
{
 /*String com expoente fracion�rio de z*/
  short i,f;

  i=n/d;
  f=n%d;
  if (i>0&&f>0)
    sprintf(txt,"%hd %hd/%hd",i,f,d);
  else if (i==0&&f>0)
    sprintf(txt,"%hd/%hd",f,d);
  else if (f==0)
    sprintf(txt,"%hd",i);
  else
    strcpy(txt,"0");
  while (strlen(txt)<8)
    strcat(txt," ");
  return strcpy(Result,txt);
}

void ListarPequeno(polpequeno *A)
{
  short FORLIM;
  char STR2[256];
  char STR3[256];

  FORLIM=A->g;
  for (i=0; i<=FORLIM; i++) {
      j=A->minpot+i*fases;
      sprintf(STR2,"% .10e z^(%s)",A->cre[i],Expoente(STR3,j,fases));
      Saida(STR2);
  }
}

void ListarGrande(void)
{
  short FORLIM;
  char STR2[256];
  char STR3[256];

  FORLIM=Nglobal.g;
  for (i=0; i<=FORLIM; i++) {
      sprintf(STR2,"% .10e z^(%s)",Nglobal.cf[i],Expoente(STR3,i,fases));
      Saida(STR2);
  }
}

void GerarGlobal(void)
{
  numeradores Num;
  short j,k,jj,kk,FORLIM2;

  if (stiponum->v.ssetting.sel_setting==1) {
      jmin=tfj->v.stextfield.panel_int;
      jmax=jmin;
      kmin=tfk->v.stextfield.panel_int;
      kmax=kmin;
  }
  else {
      jmin=1;
      jmax=fases;
      kmin=1;
      kmax=fases;
  }
  if (Adjunto())
    memcpy(Num,Apa,sizeof(numeradores));
  else
    memcpy(Num,Npa,sizeof(numeradores));
  for (i=0; i<=grandemax; i++)
    Nglobal.cf[i]=0.0;
  Nglobal.g=0;
  for (j=jmin-1; j<jmax; j++) {
      for (k=kmin-1; k<kmax; k++) {
          if (Adjunto())
	    kk=L[j][tsaida->v.stextfield.panel_int];
          else
	    kk=C[j][tsaida->v.stextfield.panel_int];
          if (kk!=0) {
              FORLIM2=Num[kk-1][k].g;
              for (i=0; i<=FORLIM2; i++) {
                  jj=i*fases+Num[kk-1][k].minpot;
                  Nglobal.cf[jj]+=Num[kk-1][k].cre[i];
                  if (Nglobal.g<jj)
                    Nglobal.g=jj;
              }
          }
      }
  }
  while (Nglobal.g>0&&fabs(Nglobal.cf[Nglobal.g])<tminimo->v.stextfield.panel_real)
    Nglobal.g--;
}

#define imax            50

/* variables for CalcularRaizes: */
struct LOC_CalcularRaizes {
  polpequeno *peq;
  raizes *R;
} ;

void ConverterRaizes(struct LOC_CalcularRaizes *LINK)
{
  raizes NR,*WITH;
  double m,f,f1;
  short FORLIM;
  double TEMP,TEMP1;

  WITH=LINK->R;
  k=LINK->peq->minpot;
  NR.g=WITH->g*fases+k;
  for (i=1; i<=k; i++) { /*Acrescentar ra�zes em z=0*/
      NR.re[i-1]=0.0;
      NR.im[i-1]=0.0;
  }
  FORLIM=WITH->g;
  for (i=1; i<=FORLIM; i++) {
      if (WITH->re[i-1]==0) {
          f=M_PI/2;
          if (WITH->im[i-1]<0)
            f=-f;
      }
      else {
          f=atan(WITH->im[i-1]/WITH->re[i-1]);
          if (WITH->re[i-1]<0) {
              if (WITH->im[i-1]>0)
                f=M_PI+f;
              else
                f-=M_PI;
          }
      }
      if (WITH->re[i-1]==0&&WITH->im[i-1]==0)
        m=0.0;
      else {
          TEMP=WITH->re[i-1];
          TEMP1=WITH->im[i-1];
          m=Ex(sqrt(TEMP*TEMP+TEMP1*TEMP1),1.0/fases);
      }
      for (j=1; j<=fases; j++) {
          k++;
          f1=(f+(j-1)*2*M_PI)/fases;
          NR.re[k-1]=m*cos(f1);
          NR.im[k-1]=m*sin(f1);
      }
  }
  *LINK->R=NR;
}

void CalcularRaizes(polpequeno *peq_,polgrande *gnd,raizes *R_,
                           boolean calculandopolos,boolean global)
{ /*Programa principal CalcularRaizes*/
  struct LOC_CalcularRaizes V;
  coefgrande a1,a2,c1,c2;
  double tolm,t,tol,p1,p2,d,xr,xi,p,d1,d2,e1,e2;
  boolean feito;
  short nn,n,ordem;
  char STR2[256],STR3[256];
  double TEMP,TEMP1;

  V.peq=peq_;
  V.R=R_;
  if (global) {
      n=gnd->g;
      memcpy(a1,gnd->cf,sizeof(coefgrande));
  }
  else {
      n=V.peq->g;
      for (i=0; i<=n; i++)
        a1[i]=V.peq->cre[i];
  }
  tol=ttolz->v.stextfield.panel_real;
  ordem=0;
  tolm=ttolp->v.stextfield.panel_real;
  xr=treal->v.stextfield.panel_real;
  xi=timag->v.stextfield.panel_real;
  feito=FALSE;
  nn=0;
  V.R->g=n;
  if (n<1) {
      if (!global&&V.peq->minpot>0&&a1[0]!=0) {
	  sprintf(STR2,"%hd roots at z^(1/%hd)=0",
		  V.peq->minpot,fases);
	  Saida(STR2);
          goto _LFim;
      }
      Saida("* No roots to compute");
      return;
  }
  if (!calculandopolos) {
      for (i=0; i<=n; i++)
        a1[i]/=a1[n];
  }
  for (i=0; i<=n; i++)
    a2[i]=0.0;
  ttysw_output(ttymsg,"Computing...");
 /*Elimina��o de ra�zes na origem*/
  while (n>1&&a1[0]==0) {
      V.R->re[n-1]=0.0;
      V.R->im[n-1]=0.0;
      sprintf(STR3,"%hd ",n);
      ttysw_output(ttymsg,STR3);
      n--;
      for (i=0; i<=n; i++)
        a1[i]=a1[i+1];
  }
  while (!feito) {
      if (kbhit()) {
	  Saida("\n* Interrupted");
          return;
      }
      if (n>1) {
 /*Calculo dos valores do polin�mio (p) e de sua derivada (d)*/
          d1=a1[n];
          p1=d1;
          d2=a2[n];
          p2=d2;
          for (i=n-1; i>=0; i--) {
              p1=Rmult(p1,p2,xr,xi)+a1[i];
              p2=Ires+a2[i];
              if (i>0) {
                  d1=Rmult(d1,d2,xr,xi)+p1;
                  d2=Ires+p2;
              }
          }
 /*C�lculo do erro. Esta forma dificulta overflow*/
          if (d1==0||d2==0) {
              d=d1*d1+d2*d2;
              e1=(p1*d1+p2*d2)/d;
              e2=(p2*d1-p1*d2)/d;
          }
          else {
              d=d1/d2+d2/d1;
              e1=(p1/d2+p2/d1)/d;
              e2=(p2/d2-p1/d1)/d;
          }
 /*Testa poss�vel ra�z m�ltipla*/
          d=fabs(d1)+fabs(d2);
          p=fabs(p1)+fabs(p2);
          if (d<tolm&&p<tolm) {
 /*Deriva o polin�mio e continua*/
              if (ordem==0) {
                  memcpy(c1,a1,sizeof(coefgrande));
                  memcpy(c2,a2,sizeof(coefgrande));
              }
              for (i=1; i<=n; i++) {
                  a1[i-1]=a1[i]*i/n;
                  a2[i-1]=a2[i]*i/n;
              }
              n--;
              ordem++;
              ttysw_output(ttymsg,"+");
              continue;
          }
 /*Atualiza ra�zes*/
          xr-=e1;
          xi-=e2;
 /*Testa converg�ncia*/
          t=fabs(e1)+fabs(e2);
          if (t<tol) {
 /*Armazena ra�zes calculadas*/
              for (i=n+ordem; i>=n; i--) {
		  sprintf(STR3,"%hd ",i);
                  ttysw_output(ttymsg,STR3);
                  V.R->re[i-1]=xr;
                  V.R->im[i-1]=xi;
              }
 /*Rep�e polin�mio original, se for o caso*/
              if (ordem>0) {
                  memcpy(a1,c1,sizeof(coefgrande));
                  memcpy(a2,c2,sizeof(coefgrande));
                  n+=ordem;
              }
 /*Deflaciona polin�mio*/
              for (i=0; i<=ordem; i++) {
                  for (j=n-1; j>=1; j--) {
 /*Ha alguma otimizacao que faz isto nao funcionar (I?)*/
                      a1[j]=Rmult(a1[j+1],a2[j+1],xr,xi)+a1[j];
                      a2[j]=Ires+a2[j];
                  }
                  n--;
                  for (j=0; j<=n; j++) {
                      a1[j]=a1[j+1];
                      a2[j]=a2[j+1];
                  }
              }
 /*Prepara c�lculo da pr�xima ra�z (igual ao EletSim*/
              if (fabs(xi)>0.01)
                xi=-xi;
              else
                xi=0.1;
              if (ordem>0) /*Evita derivada 0 a seguir*/
                xr-=0.01;
              ordem=0;
              nn=0;
              continue;
          }
          nn++;
 /*Demorando a convergir*/
          if (nn<=imax)
            continue;
	  Saida("\n* Convergence problems.");
	  if (ordem>0) {
	      sprintf(STR3,"* Root of multiplicity %hd",ordem+1);
	      Saida(STR3);
	  }
	  sprintf(STR3,"  Present error:       %g",t);
	  Saida(STR3);
	  sprintf(STR3,"  Polynomial magnitude:%g",p);
	  Saida(STR3);
	  sprintf(STR3,"  Derivative magnitude:%g",d);
	  Saida(STR3);
	  sprintf(STR3,"  Tol. for magnitudes: %g",tolm);
	  Saida(STR3);
	  sprintf(STR3,"  Real approximation:  %g",xr);
	  Saida(STR3);
	  sprintf(STR3,"  Imag approximation:  %g",xi);
	  Saida(STR3);
	  tol*=10;
	  sprintf(STR3,"  Tol. for error increased to %g",tol);
	  Saida(STR3);
	  nn=0;
	  continue;
      }
      TEMP=a1[1];
      TEMP1=a2[1];
 /*Ultimas ra�zes*/
      d=-(TEMP*TEMP+TEMP1*TEMP1);
      xr=(a1[0]*a1[1]+a2[0]*a2[1])/d;
      xi=(a2[0]*a1[1]-a1[0]*a2[1])/d;
      feito=TRUE;
      nn=0;
      for (i=n+ordem; i>=n; i--) {
	  sprintf(STR3,"%hd ",i);
	  ttysw_output(ttymsg,STR3);
	  V.R->re[i-1]=xr;
	  V.R->im[i-1]=xi;
      }
  }
  Saida("");
_LFim:
  if (!global)
    ConverterRaizes(&V);
  if (calculandopolos)
    polos_validos=TRUE;
  else
    zeros_validos=TRUE;
}

#undef imax

void CalcularPoloseZeros(void)
{
  char STR1[256];
  char STR2[256];

  if (!polos_validos) {
      Saida("Computing roots of denominator");
      CalcularRaizes(&Nden,&Nglobal,&Polos,TRUE,FALSE);
  }
  if (zeros_validos) return;
  sprintf(STR2,"Computing roots of %s",NomeAtual(STR1));
  Saida(STR2);
  if (stiponum->v.ssetting.sel_setting==2) {
      GerarGlobal();
      CalcularRaizes(&Nden,&Nglobal,&Zeros,FALSE,TRUE);
      return;
  }
  if (Adjunto()) {
      k=L[tfj->v.stextfield.panel_int-1][tsaida->v.stextfield.panel_int];
      if (k!=0)
	CalcularRaizes(&Apa[k-1][tfk->v.stextfield.panel_int-1],&Nglobal,&Zeros,
                       FALSE,FALSE);
      else
	Saida("* No roots to compute");
      return;
  }
  k=C[tfj->v.stextfield.panel_int-1][tsaida->v.stextfield.panel_int];
  if (k!=0)
    CalcularRaizes(&Npa[k-1][tfk->v.stextfield.panel_int-1],&Nglobal,&Zeros,
                   FALSE,FALSE);
  else
    Saida("* No roots to compute");
}

void ListarRaizes(raizes *R, char* titulo)
{
  char STR2[256];

  sprintf(STR2,"%s roots in the z^(1/%hd) domain:",titulo,fases);
  Saida(STR2);
  for (i=1; i<=R->g; i++) {
    sprintf(txt,"z(%hd):%g",i,R->re[i-1]);
    if (fabs(R->im[i-1])>ttolz->v.stextfield.panel_real)
    sprintf(txt+strlen(txt)," %gj",R->im[i-1]);
    Saida(txt);
  }
}

void IniciarGrafico(Xv_opaque painel,double x1,double x2,double y1,
			   double y2,short xmax,short ymax,boolean xlog)
{
  double ax,bx,ay,by,t1,t2;
  char STR1[256];
  char STR3[256];

  setfillstyle(SOLID_FILL,painel->back_color);
  bar(0,0,painel->dx,painel->dy);
  ay=(ymax-ymin)/(y1-y2);
  by=ymax-ay*y1;
  if (!xlog) {
      ax=(xmax-xmin)/(x2-x1);
      bx=xmin-ax*x1;
  }
  else {
      ax=(xmax-xmin)/log(x2/x1);
      bx=xmin-ax*log(x1);
  }
  if (x2<=x1||y2<=y1)
    grade=FALSE;
  if (grade) {
      setlinestyle(DOTTED_LINE,0,NORM_WIDTH);
      setcolor(cor[3]);
      if (xlog&&x2-x1>x1)
        t1=x1;
      else
        t1=x2-x1;
      t1=exp(log(10.0)*floor(log(t1)/log(10.0)-0.499999+0.5));
      t2=floor(x1/t1+0.5+0.5)*t1;
      while (t2<x2) {
          if (!xlog) {
              i=(short)floor(ax*t2+bx+0.5);
              line(i,ymin,i,ymax);
              t2+=t1;
              continue;
          }
          if ((short)floor(t2/t1+0.5)==10) {
              t1=10*t1;
              setcolor(cor[2]);
          }
          i=(short)floor(ax*log(t2)+bx+0.5);
          line(i,ymin,i,ymax);
          t2+=t1;
          setcolor(cor[3]);
      }
      t1=y2-y1;
      t1=exp(log(10.0)*floor(log(t1)/log(10.0)-0.5+0.5));
      t2=floor(y1/t1+0.5+0.5)*t1;
      while (t2<y2) {
          i=(short)floor(ay*t2+by+0.5);
          line(xmin,i,xmax,i);
          t2+=t1;
      }
  }
  setlinestyle(SOLID_LINE,0,NORM_WIDTH);
  setcolor(cor[1]);
  line(0,ymax,xmax,ymax);
  line(xmin,ymin,xmin,getmaxy());
  sprintf(txt,"%5.1f",y2);
  outtextxy(0,ymin,txt);
  sprintf(txt,"%5.1f",y1);
  outtextxy(0,ymax-8,txt);
  sprintf(txt,"%8.3f",x1);
  while (txt[0]==' ') {
      strcpy(STR1,txt+1);
      strcpy(txt,STR1);
  }
  outtextxy(xmin+2,ymax+2,txt);
  sprintf(txt,"%8.3f",x2);
  outtextxy(xmax-64,ymax+2,txt);
  moveto(1,1);
  sprintf(STR3,"X_ASIZ - %s %s",rede,NomeAtual(STR1));
  outtext(STR3);
}

void Falha(void)
{
  Saida("* Failure in writting file");
}

void EscreverMensagens(void)
{
  char r;

  ioresult=fprintf(arquivo,"\nMessages:\n\n");
  i=ttymsg->v.stty.bstart;
  while (i!=ttymsg->v.stty.tend) {
    r=ttymsg->v.stty.Pb[i];
    ioresult=putc(r,arquivo);
    if (i<ttymsg->v.stty.bsize)
      i++;
    else
      i=0;
  }
  if (ioresult!=EOF)
    Saida("Messages written");
  else
    Falha();
}

void EscreverTabelaFrequencia(void)
{
  char STR1[256];
  char STR2[14];
  double t;

  ioresult=fprintf(arquivo,"\nFrequency response\n");
  ioresult=fprintf(arquivo,"Numerator: %s; Sw. frequency=%g Hz; Output: ",
		 NomeAtual(STR1),
		 tfs->v.stextfield.panel_real);
  if (ssh->v.ssetting.sel_setting==1)
    ioresult=fprintf(arquivo,"S/H");
  else
    ioresult=fprintf(arquivo,"Impulse");
  if (plotardesvios) {
      if (Estatistico())
	ioresult=fprintf(arquivo,"; Statistical dev.");
      else
	ioresult=fprintf(arquivo,"; Deterministic dev.");
      ioresult=fprintf(arquivo,"; Var=%g\n",tvar->v.stextfield.panel_real);
  }
  else
    ioresult=putc('\n',arquivo);
  sprintf(STR2,"Freq. (%s)",unid[srads->v.ssetting.sel_setting-1]);
  ioresult=fprintf(arquivo,"\n%*s%*s%*s",
		 cm,STR2,cm,"Gain (dB)",cm,"Phase (deg)");
  if (plotardesvios)
    ioresult=fprintf(arquivo,"%*s%*s%*s%*s",cm,"DevG (dB)",cm,"DevP (deg)",
      cm,"Gain-DevG (dB)",cm,"Gain+DevG (dB)");
  ioresult=fprintf(arquivo,"\n\n");
  for (i=0; i<=ultimof; i++) {
      ioresult=fprintf(arquivo,"%*.*f%*.*f%*.*f",
		     cm,dc,Frq[i],cm,dc,Gan[i],cm,dc,
		     Ang[i]);
      if (plotardesvios) {
        t=tvar->v.stextfield.panel_real;
	ioresult=fprintf(arquivo,"%*.*f%*.*f%*.*f%*.*f",
		       cm,dc,t*Dgan[i],
                       cm,dc,t*Dang[i],
                       cm,dc,Gan[i]-t*Dgan[i],
                       cm,dc,Gan[i]+t*Dgan[i]
                       );
      }
      ioresult=putc('\n',arquivo);
  }
  if (ioresult!=EOF)
    Saida("Frequency response table written");
  else
    Falha();
}

void EscreverTabelaTransiente(void)
{
  char STR1[256];

  ioresult=fprintf(arquivo,"\nTransient response:\nInput: %g A ",
		 tampl->v.stextfield.panel_real);
  switch (sinput->v.ssetting.sel_setting) {

    case 3:
      sprintf(txt,"sinusoid: %g Hz, %g degrees",
	      tfreq->v.stextfield.panel_real,
	      tfase->v.stextfield.panel_real);
      break;

    case 2:
      strcpy(txt,"impulse");
      break;

    case 1:
      strcpy(txt,"step");
      break;
  }
  ioresult=fprintf(arquivo,"%s\n",txt);
  ioresult=fprintf(arquivo,"Numerator: %s; Sw. frequency=%g Hz\n",
		 NomeAtual(STR1),
		 tfs->v.stextfield.panel_real);
  ioresult=fprintf(arquivo,"\n%*s%*s%*s\n\n",
		 cm,"Time (s)",cm,"Vi (V)",cm,"Vo (V)");
  for (i=0; i<=ultimot; i++)
    ioresult=fprintf(arquivo,"%*.*f%*.*f%*.*f\n",
		   cm,dc,Tempo[i],cm,dc,Vi[i],cm,dc,Vo[i]);
  if (ioresult!=EOF)
    Saida("Transient response table written");
  else
    Falha();
}

void AbrirJRelatorio(tipotabela porque)
{
  if (!netlist_valido) {
      Saida("* No netlist read");
      return;
  }
  sprintf(trelatorio->v.stextfield.panel_value,"%s.siz",rede);
  asalvar=porque;
  open_window(jrelatorio);
}

void ListarDenominador(void)
{
  if (!AnaliseValida()) return;
  Saida("Denominator:");
  ListarPequeno(&Nden);
}

void InvalidarNumerador(Xv_opaque obj)
{
  zeros_validos=FALSE;
  frequencia_valida=FALSE;
  transiente_valido=FALSE;
}

void InvalidarAnalise(Xv_opaque obj)
{
  analise_valida=FALSE;
  zeros_validos=FALSE;
  polos_validos=FALSE;
  frequencia_valida=FALSE;
  transiente_valido=FALSE;
}

void InvalidarFrequencia(Xv_opaque obj)
{
  frequencia_valida=FALSE;
}

void InvalidarRaizes(Xv_opaque obj)
{
  polos_validos=FALSE;
  zeros_validos=FALSE;
}

void InvalidarTransiente(Xv_opaque obj)
{
  transiente_valido=FALSE;
}

void InvalidarNetlist(Xv_opaque obj)
{
  netlist_valido=FALSE;
  InvalidarAnalise(NULL);
}

void Abrirjpanalise(Xv_opaque obj)
{
  if (netlist_valido)
    open_window(jpanalise);
  else
    Saida("* No netlist read");
}

/* variables for LerNetList: */
struct LOC_LerNetList {
  short maior,menor;
} ;

void Ordenar(short a,short b,struct LOC_LerNetList *LINK)
{
  char STR1[256];

  if (a>b) {
      LINK->maior=a;
      LINK->menor=b;
      return;
  }
  if (a<b) {
      LINK->maior=b;
      LINK->menor=a;
  }
  else {
      sprintf(STR1,"%s: Forbidden circuit",txt);
      ErroFatal(STR1);
  }
}

void MaisUm(void)
{
  char STR2[256];

  e++;
  if (e>elmax) {
      sprintf(STR2,"The maximum number of effective elements is %hd",elmax);
      ErroFatal(STR2);
  }
}

void Somar(short (*C)[nosmax+1],short a,short b,short f,
		 struct LOC_LerNetList *LINK)
{
 /*"Soma" linhas ou colunas*/
  short i,j;

  Ordenar(C[f-1][a],C[f-1][b],LINK);
  for (i=0; i<fases; i++) {
      for (j=1; j<=variaveis; j++) {
          if (C[i][j]==LINK->maior)
            C[i][j]=LINK->menor;
          if (C[i][j]>LINK->maior)
            C[i][j]--;
      }
  }
}

void TestarVariaveis(void)
{
  char STR2[256];

  if (variaveis>nosmax) {
      sprintf(STR2,"The maximum number of variables is %hd",nosmax);
      ErroFatal(STR2);
  }
}

void SomarEquacoes(short a,short b,short *x,struct LOC_LerNetList *LINK)
{
 /*"Soma" linhas, alocando a eq. "maior" para x*/
  short i,j;

  variaveis++;
  TestarVariaveis();
  *x=variaveis;
  for (i=0; i<fases; i++) {
      Ordenar(L[i][a],L[i][b],LINK);
      for (j=1; j<=variaveis; j++) {
	  if (L[i][j]==LINK->maior)
	    L[i][j]=LINK->menor;
      }
      L[i][variaveis]=LINK->maior;
      C[i][variaveis]=0;
  }
}

void TestarFase(short f)
{
  char STR1[256];

  if (f<1||f>fases) {
      sprintf(STR1,"%s: Invalid phase",txt);
      ErroFatal(STR1);
  }
}

void LerNetList(Xv_opaque obj)
{
  struct LOC_LerNetList V;
  double Gm0,Gds;
  short ng,ns,nd;
  char mnome[tamnome+1];
  Xv_opaque WITH;
  char STR1[74];
  char STR2[78];
  char STR3[256];
  char STR4[256],STR5[256];
  _REC_NetList *WITH1;
  char STR7[256];
  char STR9[12];
  _REC_NetList *WITH2;
  double DUMMY;

  close_window(jnetlist);
  close_window(jdiretorio);
  if (relatorio) {
      fclose(arquivo);
      relatorio=FALSE;
  }
  ok=FALSE;
  WITH=tnetlist;
  if (pos('.',WITH->v.stextfield.panel_value)==0) {
      strcat(WITH->v.stextfield.panel_value,".net");
  }
  sprintf(rede,"%.*s",
	  pos('.',WITH->v.stextfield.panel_value)-1,WITH->v.stextfield.panel_value);
  arquivo=fopen(WITH->v.stextfield.panel_value,"r");
  ok=(arquivo!=0);
  if (!ok) {
      sprintf(STR2,"* File %s not found",WITH->v.stextfield.panel_value);
      Saida(STR2);
      return;
  }
  sprintf(STR1,"Reading file %s",WITH->v.stextfield.panel_value);
  Saida(STR1);
  fscanf(arquivo,"%hd",&nos);
  variaveis=nos;
  sprintf(STR4,"Number of nodes: %hd",nos);
  Saida(STR4);
  TestarVariaveis();
  fases=tfases->v.stextfield.panel_int;
  fasesatual=fases;
  equacoes=nos*fases;
  for (i=1; i<=fases; i++) {
      for (j=0; j<=nos; j++) {
	  if (j==0)
	    k=0;
	  else
	    k=j+(i-1)*nos;
	  C[i-1][j]=k;
	  L[i-1][j]=k;
      }
  }
  Saida("Circuit description:");
  e=0;
  while (fscanf(arquivo,"%s",STR1)!=EOF) {
      MaisUm();
      WITH1=&NetList[e-1];
      STR1[5]='\0';
      strcpy(WITH1->nome,STR1);
      sprintf(txt,"%s: ",WITH1->nome);
      switch (WITH1->nome[0]) {

	case 'V':
	  fscanf(arquivo,"%hd%hd%lg%*[^\n]",&WITH1->n1,&WITH1->n2,
		 &WITH1->UU.U3.Vs);
	  getc(arquivo);
	  sprintf(txt+strlen(txt),"%hd(v+),%hd(v-),%g(Vs)",
		  WITH1->n1,WITH1->n2,WITH1->UU.U3.Vs);
	  WITH1->tipo=fonteV;
	  SomarEquacoes(WITH1->n1,WITH1->n2,&WITH1->UU.U3.nox,&V);
	  break;

	case 'E':
	case 'A':
	  if (WITH1->nome[0]=='E') {
	      fscanf(arquivo,"%hd%hd%hd%hd%lg%*[^\n]",&WITH1->n1,&WITH1->n2,
		     &WITH1->UU.U7.n3c,&WITH1->UU.U7.n4c,&WITH1->UU.U7.Av);
	      getc(arquivo);
	  }
	  else {
	      fscanf(arquivo,"%hd%hd%hd%lg%*[^\n]",&WITH1->UU.U7.n4c,
		     &WITH1->UU.U7.n3c,&WITH1->n1,&WITH1->UU.U7.Av);
	      getc(arquivo);
	      WITH1->n2=0;
	  }
	  sprintf(txt+strlen(txt),"%hd(vo+),%hd(vo-),%hd(vi+),%hd(vi-),%g(Av)",
		  WITH1->n1,WITH1->n2,WITH1->UU.U7.n3c,WITH1->UU.U7.n4c,
		  WITH1->UU.U7.Av);
	  WITH1->tipo=VCVS;
	  SomarEquacoes(WITH1->n1,WITH1->n2,&WITH1->UU.U7.noxc,&V);
	  break;

	case 'M':
	  strcpy(mnome,WITH1->nome);
	  fscanf(arquivo,"%hd%hd%hd%lg%lg%*[^\n]",&nd,&ng,&ns,&Gm0,&Gds);
	  getc(arquivo);
	  WITH1->tipo=VCCS;
	  sprintf(STR9,"Gm_%s",WITH1->nome);
	  strcpy(WITH1->nome,STR9);
	  WITH1->n1=nd;
	  WITH1->n2=ns;
	  WITH1->UU.U6.n3=ng;
	  WITH1->UU.U6.n4=ns;
	  WITH1->UU.U6.Gm=Gm0;
	  sprintf(txt+strlen(txt),"%hd(d),%hd(g),%hd(s),%g(Gm)",
		  WITH1->n1,WITH1->UU.U6.n3,WITH1->n2,WITH1->UU.U6.Gm);
	  if (sgds->v.ssetting.sel_setting==2)
	    Gds=Gm0*tgds->v.stextfield.panel_real;
	  if (Gds!=0.0) {
	      MaisUm();
	      WITH2=&NetList[e-1];
	      WITH2->tipo=resistor;
	      sprintf(WITH2->nome,"Rd_%s",mnome);
	      WITH2->n1=nd;
	      WITH2->n2=ns;
	      WITH2->UU.Res=1/Gds;
	      sprintf(txt+strlen(txt),",%g(Gds)",Gds);
	  }
	  MaisUm();
	  WITH2=&NetList[e-1];
	  WITH2->tipo=capacitor;
	  sprintf(WITH2->nome,"Cgs%s",mnome);
	  WITH2->n1=ng;
	  WITH2->n2=ns;
	  if (scap->v.ssetting.sel_setting==1)
	    WITH2->UU.Cap=1.0;
	  else {
	      WITH2->UU.Cap=Gm0*tcgs->v.stextfield.panel_real;
	      sprintf(txt+strlen(txt),",%g(Cgs)",WITH2->UU.Cap);
	  }
	  if (scap->v.ssetting.sel_setting==2&&tcgd->v.stextfield.panel_real!=0) {
	      MaisUm();
	      WITH2=&NetList[e-1];
	      WITH2->tipo=capacitor;
	      sprintf(WITH2->nome,"Cgd%s",mnome);
	      WITH2->n1=ng;
	      WITH2->n2=nd;
	      WITH2->UU.Cap=Gm0*tcgd->v.stextfield.panel_real;
	      sprintf(txt+strlen(txt),",%g(Cgd)",WITH2->UU.Cap);
	  }
	  break;

	case 'R':
	  fscanf(arquivo,"%hd%hd%lg%*[^\n]",&WITH1->n1,&WITH1->n2,
		 &WITH1->UU.Res);
	  getc(arquivo);
	  sprintf(txt+strlen(txt),"%hd(a),%hd(b),%g(R)",
		  WITH1->n1,WITH1->n2,WITH1->UU.Res);
	  WITH1->tipo=resistor;
	  break;

	case 'G':
	  fscanf(arquivo,"%hd%hd%hd%hd%lg",&WITH1->n1,&WITH1->n2,
		 &WITH1->UU.U6.n3,&WITH1->UU.U6.n4,&WITH1->UU.U6.Gm);
	  sprintf(txt+strlen(txt),"%hd(i+),%hd(i-),%hd(v+),%hd(v-),%g(Gm)",
		  WITH1->n1,WITH1->n2,WITH1->UU.U6.n3,WITH1->UU.U6.n4,
		  WITH1->UU.U6.Gm);
	  WITH1->tipo=VCCS;
	  break;

	case 'C':
	  fscanf(arquivo,"%hd%hd%lg%*[^\n]",&WITH1->n1,&WITH1->n2,
		 &WITH1->UU.Cap);
	  getc(arquivo);
	  sprintf(txt+strlen(txt),"%hd(a),%hd(b),%g(C)",
		  WITH1->n1,WITH1->n2,WITH1->UU.Cap);
	  WITH1->tipo=capacitor;
	  break;

	case 'I':
	  fscanf(arquivo,"%hd%hd%lg%*[^\n]",&WITH1->n1,&WITH1->n2,
		 &WITH1->UU.Is);
	  getc(arquivo);
	  sprintf(txt+strlen(txt),"%hd(i+),%hd(i-),%g(Is)",
		  WITH1->n1,WITH1->n2,WITH1->UU.Is);
	  WITH1->tipo=fonteI;
	  break;

	case 'S':
	  fscanf(arquivo,"%hd%hd",&WITH1->n1,&WITH1->n2);
	  sprintf(txt+strlen(txt),"%hd(a),%hd(b)",
		  WITH1->n1,WITH1->n2);
	  do {
	    k=fscanf(arquivo,"%c",&ch);
	    if (k!=EOF && ch==' ') {
	      fscanf(arquivo,"%hd",&WITH1->UU.fase);
	      TestarFase(WITH1->UU.fase);
	      Somar(C,WITH1->n1,WITH1->n2,WITH1->UU.fase,&V);
	      Somar(L,WITH1->n1,WITH1->n2,WITH1->UU.fase,&V);
	      equacoes--;
	      sprintf(txt+strlen(txt),",%hd",WITH1->UU.fase);
	    }
	  }
	  while (ch!='\n' && k!=EOF);
	  e--;
	  break;

	case 'O':
	  fscanf(arquivo,"%hd%hd%hd",&WITH1->n1,&WITH1->n2,&WITH1->UU.nout);
	  sprintf(txt+strlen(txt),"%hd(-/+),%hd(+/-),%hd(vo)",
		  WITH1->n1,WITH1->n2,WITH1->UU.nout);
	  for (i=1; i<=fases; i++) {
		 /*Amp. Ops. n�o s�o guardados tamb�m*/
		      Somar(C,WITH1->n1,WITH1->n2,i,&V);
	      Somar(L,0,WITH1->UU.nout,i,&V);
	      equacoes--;
	  }
	  e--;
	  break;

	case '*':
	  fgets(txt,256,arquivo);
	  e--;
	  break;

	default:
	  sprintf(STR3,"%s Unknown element",txt);
	  ErroFatal(STR3);
	  break;
      }
      Saida(txt);
  }
  fclose(arquivo);
  elementos=e;
  close_window(jsensi);
  for (e=1; e<=elementos; e++) {
      WITH1=&NetList[e-1];
      WITH1->selecionado=(WITH1->tipo==VCCS);
      WITH1->grupo='*';
  }
  sprintf(STR7,"Number of effective elements: %hd",elementos);
  Saida(STR7);
  sprintf(STR7,"Equations in the resulting system: %hd",equacoes);
  Saida(STR7);
  if (equacoes>linmax) {
      sprintf(STR7,"The maximum number of equations is %hd",linmax);
      ErroFatal(STR7);
  }
  sprintf(STR7,"Number of variables: %hd",variaveis);
  Saida(STR7);

 /*O algor�tmo abaixo funciona corretamente se n�o existirem elementos
    resistivos que fiquem ligados apenas a capacitores em alguma fase,
    quando o grau m�ximo ser� subestimado e sistema ser� singular*/

  for (i=0; i<=equacoes; i++)
    Eqcap[i]=TRUE;
  for (e=1; e<=elementos; e++) {
      WITH1=&NetList[e-1];
      if (WITH1->tipo!=capacitor) {
	  for (i=1; i<=fases; i++) {
	      Eqcap[L[i-1][WITH1->n1]]=FALSE;
	      Eqcap[L[i-1][WITH1->n2]]=FALSE;
	      if (WITH1->tipo==fonteV||WITH1->tipo==VCVS)
		Eqcap[L[i-1][WITH1->UU.U3.nox]]=FALSE;
	  }
      }
  }
 /*O m�ximo grau de polin�mio que aparece � o n�mero de equa��es capacitivas*/
  capacitivas=0;
  for (i=1; i<=equacoes; i++) {
      if (Eqcap[i])
	capacitivas++;
  }
  maxz=capacitivas;
  i=maxz/fases;
  if (modf((double)maxz/fases,&DUMMY)!=0) {
      i++;
      sprintf(STR5,"Introduced %hd extra zeros/poles at zero in z^(1/%hd)",
	      maxz%fases,fases);
      Saida(STR5);
  }
  sprintf(STR7,"Maximum complexity order (in z): %hd",i);
  Saida(STR7);
  tgrau->v.stextfield.panel_int=i;
  tfk->v.stextfield.max_value=fases;
  tfj->v.stextfield.max_value=fases;
  netlist_valido=TRUE;
  InvalidarAnalise(NULL);
  tnsaida->v.stextfield.max_value=variaveis;
  tsaida->v.stextfield.max_value=variaveis;
  if (tsaida->v.stextfield.panel_int>variaveis)
    tsaida->v.stextfield.panel_int=1;
  if (tnsaida->v.stextfield.panel_int>variaveis)
    tsaida->v.stextfield.panel_int=1;
  open_window(jpanalise);
}

void AnalisarCircuito(Xv_opaque obj)
{
  if (!netlist_valido) {
      Saida("* No netlist read");
      return;
  }
  close_window(jpanalise);
  if (!analise_valida) {
      AnalisarNoCirculo();
      InterpolarPolinomios();
      analise_valida=TRUE;
  }
  ListarDenominador();
  open_window(jpnumerador);
  menu_show(menu1);
}

void InvalidarDesvios(Xv_opaque obj)
{
  if (ssensi->v.ssetting.sel_setting!=1) {
      desvios_validos=FALSE;
      return;
  }
  if (!frequencia_valida)
    desvios_validos=FALSE;
  if (!desvios_validos)
    frequencia_valida=FALSE;
  open_window(jpfrequencia);
}

void DesenharSensi(Xv_opaque obj)
{
  short x,y;
  _REC_NetList *WITH;
  char STR1[256];

  if (!netlist_valido)
    return;
  npl=csensi->dx/60;
  settextstyle(SMALL_FONT,HORIZ_DIR,4);
  for (e=1; e<=elementos; e++) {
      WITH=&NetList[e-1];
      x=(e-1)%npl*60+1;
      y=(e-1)/npl*8;
      outtextxy(x+6,y,WITH->nome);
      if (WITH->selecionado) {
          sprintf(STR1,"%c",WITH->grupo);
          outtextxy(x,y,STR1);
      }
  }
  outtextxy(1,y+8,"Prefixes a..z: correlated groups; *: uncorrelated");
  outtextxy(1,y+16,"Change w/mouse and [a]..[z], [*] keys");
  outtextxy(1,y+24,"Press [s] in the fr. resp. graph to list sensitivities");
}

void MudarElementos(Xv_opaque obj)
{
  short x,y;
  _REC_NetList *WITH;
  char STR1[256];

  if (!netlist_valido)
    return;
  if (ie_code=='*'||(ie_code>='a'&&ie_code<='z')) {
      grupoatual=(char)ie_code;
      return;
  }
  if (ie_shiftcode<=0)
    return;
  x=ie_locx/60+1;
  if (x>npl)
    return;
  e=(ie_locy-3)/8*npl+x;
  if (e<=0||e>elementos)
    return;
  settextstyle(SMALL_FONT,HORIZ_DIR,4);
  WITH=&NetList[e-1];
  x=(e-1)%npl*60+1;
  y=(e-1)/npl*8;
  WITH->selecionado=(ie_shiftcode==1);
  setfillstyle(SOLID_FILL,csensi->back_color);
  bar(x,y+2,x+5,y+9);
  if (WITH->selecionado) {
      WITH->grupo=grupoatual;
      sprintf(STR1,"%c",WITH->grupo);
      outtextxy(x,y,STR1);
  }
  frequencia_valida=FALSE;
}

short Ly(double y)
{
  if (y>yfmax)
    y=yfmax;
  else if (y<ymin)
    y=ymin;
  return((short)floor(y+0.5));
}

/* variables for PlotarTransferencia: */
struct LOC_PlotarTransferencia {
  polpequeno *Nden;
  double na,nb,ta,tb,da,db;
} ;

double Nx(polpequeno *Num)
{
  double Result;
  double ta,tb,t;
  short i,FORLIM;

  if (Num->valido) {
      Result=Num->vala;
      Ires=Num->valb;
      return Result;
  }
  ta=0.0;
  tb=0.0;
  for (i=Num->g; i>=0; i--) {
      t=ta*z1-tb*z2+Num->cre[i];
      tb=ta*z2+tb*z1;
      ta=t;
  }
  FORLIM=Num->minpot;
  for (i=1; i<=FORLIM; i++) {
      ta=Rmult(ta,tb,z1f,z2f);
      tb=Ires;
  }
  Result=ta;
  Ires=tb;
  Num->vala=ta;
  Num->valb=tb;
  Num->valido=TRUE;
  return Result;
}

double dEdGm(short na,short nb,short nc,short nd,short j,short k,
		   short f1,short f2,boolean capacitivo)
{
  double va,vb,aa,ab;
  short kk;

 /*dEojk/dGmf1f2=(Ncf1k-Ndf1k)(Aaf2j-Abf2j)/(DnDa)*/
  kk=C[f1-1][nc];
  if (kk!=0) {
      va=Nx(&Npa[kk-1][k-1]);
      vb=Ires;
  }
  else {
      va=0.0;
      vb=0.0;
  }
  kk=C[f1-1][nd];
  if (kk!=0) {
      va-=Nx(&Npa[kk-1][k-1]);
      vb-=Ires;
  }
  kk=L[f2-1][na];
  if (capacitivo&&!Eqcap[kk])
    kk=0;
  if (kk!=0) {
      aa=Nx(&Apa[kk-1][j-1]);
      ab=Ires;
  }
  else {
      aa=0.0;
      ab=0.0;
  }
  kk=L[f2-1][nb];
  if (capacitivo&&!Eqcap[kk])
    kk=0;
  if (kk!=0) {
      aa-=Nx(&Apa[kk-1][j-1]);
      ab-=Ires;
  }
  return(Rmult(va,vb,aa,ab));
 /*Ainda n�o divide por DnDa*/
}

void SGm(short n1,short n2,short n3,short n4,double Gm,
               struct LOC_PlotarTransferencia *LINK)
{
  short i,j,k;

  for (j=jmin; j<=jmax; j++) {
      for (k=kmin; k<=kmax; k++) {
          for (i=1; i<=fases; i++) {
	      LINK->ta+=dEdGm(n1,n2,n3,n4,j,k,i,i,FALSE);
              LINK->tb+=Ires;
          }
      }
  }
  LINK->ta=Rdiv(LINK->ta,LINK->tb,LINK->da,LINK->db);
  LINK->tb=Ires;
  LINK->ta=Rdiv(LINK->ta,LINK->tb,LINK->na,LINK->nb)*Gm;
  LINK->tb=Ires*Gm;
}

void SIs(short n1,short n2,double Is,
               struct LOC_PlotarTransferencia *LINK)
{
  short i,j,k;

  for (j=jmin-1; j<jmax; j++) {
      for (k=kmin-1; k<kmax; k++) {
          i=L[k][n1];
          if (i!=0) {
	      LINK->ta+=Nx(&Apa[i-1][j]);
              LINK->tb+=Ires;
          }
          i=L[k][n2];
          if (i!=0) {
	      LINK->ta-=Nx(&Apa[i-1][j]);
              LINK->tb-=Ires;
          }
      }
  }
  LINK->ta=Rdiv(LINK->ta,LINK->tb,LINK->na,LINK->nb)*Is;
  LINK->tb=Ires*Is;
}

void PlotarTransferencia(polgrande *Num,polpequeno *Nden_,double *Gan,
  double *Ang,short estilo,short corganho,short corfase,boolean reter,
  boolean sensibilidade,boolean listar_resposta)
{
  struct LOC_PlotarTransferencia V;
  short i,j,k;
  double ea,eb,t,wt,sa,sb,t1,t2,t11,t22;
  double gsa[26],gsb[26];
  boolean gusado[26];
  polpequeno *WITH;
  _REC_NetList *WITH1;
  char STR1[256];
  double TEMP;

  V.Nden=Nden_;
  setlinestyle(estilo,0,NORM_WIDTH);
  if (hf>ultimof||listar_resposta) {
      wt=w/tfs->v.stextfield.panel_real;
      if (srads->v.ssetting.sel_setting==2)
        wt=2*M_PI*wt;
      z1f=cos(wt/fases);
      z2f=sin(wt/fases);
      V.na=0.0;
      V.nb=0.0;
      for (i=Num->g; i>=0; i--) {
          t=V.na*z1f-V.nb*z2f+Num->cf[i];
          V.nb=V.na*z2f+V.nb*z1f;
          V.na=t;
      }
      z1=cos(wt);
      z2=sin(wt);
      WITH=V.Nden;
      V.da=0.0;
      V.db=0.0;
      for (i=WITH->g; i>=0; i--) {
          t=V.da*z1-V.db*z2+WITH->cre[i];
          V.db=V.da*z2+V.db*z1;
          V.da=t;
      }
      if (V.da==0||V.db==0) {
          t=V.da*V.da+V.db*V.db;
          if (t==0)
            t=1e-20;
          ea=(V.na*V.da+V.nb*V.db)/t;
          eb=(V.nb*V.da-V.na*V.db)/t;
      }
      else {
          t=V.da/V.db+V.db/V.da;
          ea=(V.na/V.db+V.nb/V.da)/t;
          eb=(V.nb/V.db-V.na/V.da)/t;
      }
      ea/=fases;
      eb/=fases;
      if (reter) {
	  t=w/tfs->v.stextfield.panel_real/fases;
	  if (srads->v.ssetting.sel_setting==2)
            t=2*M_PI*t;
          if (t==0) {
              V.ta=1.0;
              V.tb=0.0;
          }
          else {
              V.ta=sin(t)/t;
              V.tb=(cos(t)-1)/t;
          }
          V.ta=Rmult(ea,eb,V.ta,V.tb);
          V.tb=Ires;
      }
      else {
          V.ta=ea;
          V.tb=eb;
      }
      if (V.ta==0) {
          if (V.tb==0)
            V.tb=1e-11;
          V.ta=V.tb;
      }
      if (!listar_resposta) {
          Ang[hf]=atan(V.tb/V.ta)*57.29577951;
          Gan[hf]=log(V.ta*V.ta+V.tb*V.tb)*4.342944819;
          if (V.ta<0) {
              if (V.tb>0)
                Ang[hf]=180+Ang[hf];
              else
                Ang[hf]-=180;
          }
          Frq[hf]=w;
      }
 /*Calculo de sensibilidades*/
      if (sensibilidade) {
 /*Assume-se (z1,z2)=Exp(jwT), (z1f,z2f)=Exp(jwT/f), Eo=(ea,eb)=(na,nb)/(da,db)*/
          sa=0.0;
          sb=0.0;
          for (i=0; i<=25; i++) {
              gusado[i]=FALSE;
              gsa[i]=0.0;
              gsb[i]=0.0;
          }
 /*Invalida todos os numeradores e o denominador*/
          for (i=0; i<equacoes; i++) {
              for (j=0; j<fases; j++) {
                  Npa[i][j].valido=FALSE;
                  Apa[i][j].valido=FALSE;
              }
          }
          V.Nden->valido=FALSE;
 /*Calcula sensibilidades*/
          for (e=1; e<=elementos; e++) {
              WITH1=&NetList[e-1];
              if (WITH1->selecionado) {
                  V.ta=0.0;
                  V.tb=0.0;
                  switch (WITH1->tipo) {

                    case resistor:
                      SGm(WITH1->n1,WITH1->n2,WITH1->n1,WITH1->n2,
                          -1/WITH1->UU.Res,&V);
                      break;

                    case VCCS:
		      SGm(WITH1->n1,WITH1->n2,WITH1->UU.U6.n3,WITH1->UU.U6.n4,
                          WITH1->UU.U6.Gm,&V);
                      break;

		    case VCVS:
		      SGm(0,WITH1->UU.U3.nox,WITH1->n1,
			  WITH1->n2,-1/WITH1->UU.U7.Av,&V);
                      break;

                    case capacitor:
                      for (j=jmin; j<=jmax; j++) {
                          for (k=kmin; k<=kmax; k++) {
                              for (i=1; i<=fases; i++) {
				  t11=dEdGm(WITH1->n1,WITH1->n2,WITH1->n1,
					      WITH1->n2,j,k,i,i,TRUE);
                                  t22=Ires;
				  t1=dEdGm(WITH1->n1,WITH1->n2,WITH1->n1,
					     WITH1->n2,j,k,
					     (i+fases-2)%fases+1,i,TRUE);
				  t2=Ires;
                                  t1=Rdiv(t1,t2,z1f,z2f);
                                  t2=Ires;
                                  V.ta+=t11-t1;
                                  V.tb+=t22-t2;
                              }
                          }
                      }
                      V.ta=Rdiv(V.ta,V.tb,V.da,V.db);
                      V.tb=Ires;
                      V.ta=Rdiv(V.ta,V.tb,V.na,V.nb)*WITH1->UU.Cap;
                      V.tb=Ires*WITH1->UU.Cap;
                      break;

                    case fonteI:
                      SIs(WITH1->n1,WITH1->n2,WITH1->UU.Is,&V);
                      break;

                    case fonteV:
		      SIs(WITH1->UU.U3.nox,0,WITH1->UU.U3.Vs,&V);
                      break;

                    default:
                      ErroFatal("??!!");
                      break;
                  }
                  if (listar_resposta) {
		      sprintf(STR1,"%s: % *.*f%+*.*fj",
			WITH1->nome,(int)(intnome-strlen(WITH1->nome)+10),6,V.ta,9,6,V.tb);
		      Saida(STR1);
                  }
                  if (Estatistico()) {
                      if (WITH1->grupo=='*') {
                          sa+=V.ta*V.ta;
                          sb+=V.tb*V.tb;
                      }
                      else {
                          i=WITH1->grupo+1-'a';
                          gusado[i-1]=TRUE;
                          gsa[i-1]+=V.ta;
                          gsb[i-1]+=V.tb;
                      }
                  }
                  else {
                      sa+=V.ta;
                      sb+=V.tb;
                  }
              }
          }
          if (Estatistico()) {
              for (i=1; i<=26; i++) {
                  if (gusado[i-1]) {
                      TEMP=gsa[i-1];
                      sa+=TEMP*TEMP;
                      TEMP=gsb[i-1];
		      sb+=TEMP*TEMP;
		      if (listar_resposta) {
			  sprintf(STR1,"Group %c:  %*.*f %*.*fj",
				  (char)(i-1+'a'),
				  9,6,gsa[i-1],
				  9,6,gsb[i-1]);
			  Saida(STR1);
		      }
		  }
	      }
	      sa=sqrt(sa);
	      sb=sqrt(sb);
	  }
          t1=8.685889638*sa;
          t2=57.29577951*sb;
          if (listar_resposta) {
            sprintf(STR1,"Deviation: %*.*f dB, %*.*f deg.",
            9,6,tvar->v.stextfield.panel_real*t1,
            9,6,tvar->v.stextfield.panel_real*t2);
            Saida(STR1);
          }
	  else {
	    Dgan[hf]=t1;
	    Dang[hf]=t2;
	  }
      }
  }
  if (listar_resposta||hf<=0)
    return;
 /*Fase*/
  j=(short)floor((hf-1)*ah+bh+0.5);
  k=(short)floor(hf*ah+bh+0.5);
  if (plotarfase) {
      setcolor(corfase);
      line(j,(short)floor(af*Ang[hf-1]+bf+0.5),k,
	   (short)floor(af*Ang[hf]+bf+0.5));
  }
 /*Ganho*/
  setcolor(corganho);
  line(j,Ly(ag*Gan[hf-1]+bg),k,Ly(ag*Gan[hf]+bg));
  if (!sensibilidade)
    return;
 /*Dfase*/
  j=(short)floor((hf-1)*ah+bh+0.5);
  k=(short)floor(hf*ah+bh+0.5);
  setcolor(cor[3]);
  setlinestyle(DOTTED_LINE,0,NORM_WIDTH);
  if (plotarfase) {
      line(j,Ly(af*(Ang[hf-1]+tvar->v.stextfield.panel_real*Dang[hf-1])+bf),k,
	   Ly(af*(Ang[hf]+tvar->v.stextfield.panel_real*Dang[hf])+bf));
      if (Estatistico())
	line(j,Ly(af*(Ang[hf-1]-tvar->v.stextfield.panel_real*Dang[hf-1])+bf),k,
	     Ly(af*(Ang[hf]-tvar->v.stextfield.panel_real*Dang[hf])+bf));
  }
 /*Dganho*/
  line(j,Ly(ag*(Gan[hf-1]+tvar->v.stextfield.panel_real*Dgan[hf-1])+bg),k,
       Ly(ag*(Gan[hf]+tvar->v.stextfield.panel_real*Dgan[hf])+bg));
  if (Estatistico())
    line(j,Ly(ag*(Gan[hf-1]-tvar->v.stextfield.panel_real*Dgan[hf-1])+bg),k,
	 Ly(ag*(Gan[hf]-tvar->v.stextfield.panel_real*Dgan[hf])+bg));
}

void AbrirPlotarFrequencia(Xv_opaque obj)
{
  double dw;
  tiporeffreq *WITH;

  if (!analise_valida) {
      if (obj!=cfrequencia)
        Saida("* No analysis made");
      return;
  }
  if (!frequencia_valida)
    ultimof=-1;
  GerarGlobal();
  while (active_w!=jfrequencia)
    close_window(active_w);
  xv_set(jfrequencia,"Frequency Response");
  yfmax=cfrequencia->dy-11;
  xfmax=cfrequencia->dx-2;
  plotardesvios=(ssensi->v.ssetting.sel_setting==1&&!Adjunto()&&
		   tnsaida->v.stextfield.panel_int==tsaida->v.stextfield.panel_int);
  ag=(yfmax-ymin)/(tgmin->v.stextfield.panel_real-tgmax->v.stextfield.panel_real);
  bg=yfmax-ag*tgmin->v.stextfield.panel_real;
  af=(ymin-yfmax)/360.0;
  bf=yfmax+af*180;
  ah=(double)(xfmax-xmin)/tsegmf->v.stextfield.panel_int;
  bh=xmin;
  if (twmin->v.stextfield.panel_real*twmax->v.stextfield.panel_real<=0)
    slog->v.ssetting.sel_setting=2;
  if (Log()) {
      dw=Ex(twmax->v.stextfield.panel_real/twmin->v.stextfield.panel_real,
	      1.0/tsegmf->v.stextfield.panel_int);
      aw=(xfmax-xmin)/log(twmax->v.stextfield.panel_real/twmin->v.stextfield.panel_real);
      bw=xfmax-aw*log(twmax->v.stextfield.panel_real);
  }
  else {
      dw=(twmax->v.stextfield.panel_real-twmin->v.stextfield.panel_real)/
	   tsegmf->v.stextfield.panel_int;
      aw=(xfmax-xmin)/(twmax->v.stextfield.panel_real-twmin->v.stextfield.panel_real);
      bw=xfmax-aw*twmax->v.stextfield.panel_real;
  }
  if (!reter_imagem) {
    IniciarGrafico(cfrequencia,twmin->v.stextfield.panel_real,twmax->v.stextfield.panel_real,
      tgmin->v.stextfield.panel_real,tgmax->v.stextfield.panel_real,xfmax,yfmax,
      Log());
    if (plotardesvios) {
      if (Estatistico())
        outtext("+stat dev");
      else
        outtext("+det dev");
    }
    moveto(xmin+2,ymin);
    outtext("dB");
  }
  if (plotarfase)
    outtext(",deg");
  outtextxy(xfmax-32,yfmax-8,unid[srads->v.ssetting.sel_setting-1]);
  w=twmin->v.stextfield.panel_real;
  hf=0;
  fcsr=0;
  colcsr=-100;
  do {
      for (i=1; i<=reffreq; i++) {
          WITH=Reff[i-1];
          fases=WITH->reffases;
          PlotarTransferencia(&WITH->Rnglobal,&WITH->Rden,WITH->Rgan,
			      WITH->Rang,SOLID_LINE,cor[7-i],cor[7-i],
                              WITH->reffreqreter,FALSE,FALSE);
      }
      fases=fasesatual;
      PlotarTransferencia(&Nglobal,&Nden,Gan,Ang,SOLID_LINE,cor[1],cor[2],
			  ssh->v.ssetting.sel_setting==1,plotardesvios,FALSE);
      if (kbhit()) {
          if (hf>ultimof)
            ultimof=hf;
          goto _LFim;
      }
      if (Log())
        w*=dw;
      else
        w+=dw;
      hf++;
  } while (hf<=tsegmf->v.stextfield.panel_int);
  hf=tsegmf->v.stextfield.panel_int;
  ultimof=hf;
_LFim:
  frequencia_valida=TRUE;
}

void Inverter(Xv_opaque obj)
{
  i=obj->fore_color;
  obj->fore_color=obj->back_color;
  obj->back_color=i;
}

void PlotarEspectro(Xv_opaque obj)
{
  double w,nw,ws,na,nb,da,db,ea,eb,ta,tb,t,wt,pa,pb,za,zb;
  int xw,nmin,nmax,n,i,j,k,n1,n2,kk;
  boolean listar;
  char STR1[256],STR2[50];

  if (!analise_valida) {
    Saida("* No analysis made");
    return;
  }
  if (Adjunto()) return; /*Remover restricao depois*/
  listar=(obj==blsp);
  w=tsp->v.stextfield.panel_real;
  AbrirPlotarFrequencia(NULL);
  if (listar) {
    sprintf(STR1,"Output spectrum for %s:\nInput frequency:%*.*f %s",NomeAtual(STR2),cm,dc,w,unid[srads->v.ssetting.sel_setting-1]);
    Saida(STR1);
  }
  else {
    settextstyle(SMALL_FONT,HORIZ_DIR,4);
    setlinestyle(SOLID_LINE,0,NORM_WIDTH);
  }
  ws=tfs->v.stextfield.panel_real;
  if (!Hertz()) ws=2*M_PI*ws;
  n1=(int)((twmin->v.stextfield.panel_real+w)/ws);
  n2=(int)((twmin->v.stextfield.panel_real-w)/ws);
  if (n1<n2) nmin=n1; else nmin=n2;
  n1=(int)((twmax->v.stextfield.panel_real+w)/ws);
  n2=(int)((twmax->v.stextfield.panel_real-w)/ws);
  if (n1>n2) nmax=n1; else nmax=n2;
  for (n=nmin; n<=nmax; n++) {
    for (i=0; i<=1; i++) {
      nw=n*ws+(2*i-1)*w;
      if (nw>=twmin->v.stextfield.panel_real && nw<=twmax->v.stextfield.panel_real) {
        if (Log()) xw=(int)(aw*log(nw)+bw); else xw=(int)(aw*nw+bw);
        wt=(2*i-1)*w/tfs->v.stextfield.panel_real;
        if (Hertz()) wt=2*M_PI*wt;
        z1=cos(wt); z2=sin(wt);
        z1f=cos(wt/fases); z2f=sin(wt/fases);
        na=0; nb=0;
        for (j=jmin; j<=jmax; j++) { /*Para cada fase da saida*/
          pa=0; pb=0;
          t=-2.0*M_PI*n*(j-1)/fases;
          za=cos(t); zb=sin(t);
          for (k=kmin; k<=kmax; k++) { /*Para cada fase da entrada*/
            kk=C[j-1][tsaida->v.stextfield.panel_int];
            if (kk!=0) {
              Npa[kk-1][k-1].valido=FALSE;
              pa=pa+Nx(&Npa[kk-1][k-1]);
              pb=pb+Ires;
            }
          }
          na=na+Rmult(pa,pb,za,zb);
          nb=nb+Ires;
        }
        Nden.valido=FALSE;
        da=Nx(&Nden); db=Ires;
        if (da==0 || db==0) {
          t=da*da+db*db;
          if (t==0) t=1e-20;
          ea=(na*da+nb*db)/t; eb=(nb*da-na*db)/t;
        }
        else {
          t=da/db+db/da;
          ea=(na/db+nb/da)/t; eb=(nb/db-na/da)/t;
        }
        ea=ea/fases;
        eb=eb/fases;
	if (ssh->v.ssetting.sel_setting==1) {
          t=nw/tfs->v.stextfield.panel_real/fases;
          if (Hertz()) t=2*M_PI*t;
          if (t==0) {ta=1; tb=0;}
          else {ta=sin(t)/t; tb=(cos(t)-1)/t;}
          ta=Rmult(ea,eb,ta,tb); tb=Ires;
        }
        else {ta=ea; tb=eb; }
        if (ta==0) {
          if (tb==0) tb=1e-11;
          ta=tb*1e-11;
        }
        pa=log(ta*ta+tb*tb)*4.342944819;
        pb=atan(tb/ta)*57.29577951;
        if (ta<0)
          if (tb>0) pb=180+pb; else pb=pb-180;
        if (listar) {
	  sprintf(STR1,"f(%2d,%+d):%9.4f %s %9.4f dB %9.4f deg",n,2*i-1,nw,unid[srads->v.ssetting.sel_setting-1],pa,pb);
          Saida(STR1);
        }
        else {
          if (n==0 && i==1) setcolor(cor[2]); else setcolor(cor[6]);
          kk=Ly(ag*pa+bg);
          line(xw,yfmax,xw,kk);
          if (kk<yfmax) {
            setfillstyle(SOLID_FILL,cor[3]);
            bar(xw+1,kk,xw+55,kk+20);
            setcolor(0);
            sprintf(STR1,"%9.4f",pa);
            outtextxy(xw+2,kk,STR1);
            sprintf(STR1,"%9.4f",pb);
	    outtextxy(xw+2,kk+8,STR1);
	  }
	}
      }
    }
  }
}

void EventosFrequencia(Xv_opaque obj)
{
  static short xi=0, yi=0, xf=0, yf=0;
  static boolean selecao=FALSE;

  double t;
  double TEMP;
  Xv_opaque WITH;
  char STR1[256],STR2[256];

  if (!frequencia_valida) return;
  if (selecao) {
    setwritemode(XOR_PUT);
    setcolor(c_cursor);
    if (ie_code==LOC_DRAG) {
      rectangle(xi,yi,xf,yf);
      xf=ie_locx;
      yf=ie_locy;
      rectangle(xi,yi,xf,yf);
      return;
    }
    if (ie_shiftcode==0) {
      selecao=FALSE;
      rectangle(xi,yi,xf,yf);
      if (xi>=xf||yi>=yf) return;
      WITH=twmin;
      WITH->v.stextfield.panel_real=(xi-bw)/aw;
      if (Log())
        WITH->v.stextfield.panel_real=exp(WITH->v.stextfield.panel_real);
      WITH=twmax;
      WITH->v.stextfield.panel_real=(xf-bw)/aw;
      if (Log())
        WITH->v.stextfield.panel_real=exp(WITH->v.stextfield.panel_real);
      tgmin->v.stextfield.panel_real=(yf-bg)/ag;
      tgmax->v.stextfield.panel_real=(yi-bg)/ag;
    }
    setwritemode(COPY_PUT);
    goto _LRecalcular;
  }

  if (ie_code<256) ie_code=toupper(ie_code);
  switch (ie_code) {

    case MS_MIDDLE:
    case LOC_DRAG:
      fcsr=(short)floor((ie_locx-bh)/ah+0.5);
      if (fcsr<0)
        fcsr=0;
      if (fcsr>ultimof)
        fcsr=ultimof;
      goto _LCursor;

    case 'L':
      if (Log())
	slog->v.ssetting.sel_setting=2;
      else
	slog->v.ssetting.sel_setting=1;
      goto _LRecalcular;

    case 'R':
      if (Log()) {
	TEMP=twmax->v.stextfield.panel_real/twmin->v.stextfield.panel_real;
	twmax->v.stextfield.panel_real=twmin->v.stextfield.panel_real*(TEMP*TEMP);
      }
      else
	twmax->v.stextfield.panel_real=twmin->v.stextfield.panel_real+
	(twmax->v.stextfield.panel_real-twmin->v.stextfield.panel_real)*2;
	goto _LRecalcular;

    case 'A':
      if (Log())
	twmax->v.stextfield.panel_real=twmin->v.stextfield.panel_real*
	sqrt(twmax->v.stextfield.panel_real/twmin->v.stextfield.panel_real);
      else
	twmax->v.stextfield.panel_real=twmin->v.stextfield.panel_real+
	(twmax->v.stextfield.panel_real-twmin->v.stextfield.panel_real)/2;
      goto _LRecalcular;

    case '>':
    case '.':
      if (Log()) {
	t=sqrt(sqrt(twmax->v.stextfield.panel_real/twmin->v.stextfield.panel_real));
	twmin->v.stextfield.panel_real*=t;
	twmax->v.stextfield.panel_real*=t;
      }
      else {
	t=(twmax->v.stextfield.panel_real-twmin->v.stextfield.panel_real)/4;
	twmin->v.stextfield.panel_real+=t;
	twmax->v.stextfield.panel_real+=t;
      }
      goto _LRecalcular;

    case '<':
    case ',':
      if (Log()) {
	t=sqrt(sqrt(twmax->v.stextfield.panel_real/twmin->v.stextfield.panel_real));
	twmin->v.stextfield.panel_real/=t;
	twmax->v.stextfield.panel_real/=t;
      }
      else {
	t=(twmax->v.stextfield.panel_real-twmin->v.stextfield.panel_real)/4;
	twmin->v.stextfield.panel_real-=t;
	twmax->v.stextfield.panel_real-=t;
      }
      goto _LRecalcular;

    case 'G':
      grade=!grade;
      goto _LRetracar;

    case 'F':
      plotarfase=!plotarfase;
      goto _LRetracar;

    case 'C':
      WITH=cfrequencia;
      if (cor[3]!=WITH->fore_color) {
	memcpy(cormono,cor,sizeof(cores));
	for (i=1; i<=6; i++)
	  cor[i]=WITH->fore_color;
	}
      else
        memcpy(cor,cormono,sizeof(cores));
      goto _LRetracar;

    case 'I':
      Inverter(cfrequencia);
      Inverter(ctransiente);
      Inverter(craizes);
      for (i=1; i<=4; i++)
        cor[i-1]=getmaxcolor()-cor[i];
      goto _LRetracar;

    case 'X':
      reter_imagem=!reter_imagem;
      if (reter_imagem) Saida("New plot retains old plot");
      else Saida("New plot erases old plot");
      return;

    case 'S':
      if (plotardesvios) {
        w=Frq[fcsr];
        sprintf(STR2,
          "Selected sensitivities dLnT(jw)/dLn(x):\nFrequency:%*.*f %s",
	  13,6,w,unid[srads->v.ssetting.sel_setting-1]);
        Saida(STR2);
	PlotarTransferencia(&Nglobal,&Nden,Gan,Ang,SOLID_LINE,cor[1],
                            cor[2],ssh->v.ssetting.sel_setting==1,
                            plotardesvios,TRUE);
      }
      return;

    case KLEFTARROW:
      if (fcsr>=1)
        fcsr--;
      goto _LCursor;

    case KRIGHTARROW:
      if (fcsr<hf)
        fcsr++;
      goto _LCursor;

    case KUPARROW:
      t=(tgmax->v.stextfield.panel_real-tgmin->v.stextfield.panel_real)/4;
      tgmin->v.stextfield.panel_real+=t;
      tgmax->v.stextfield.panel_real+=t;
      goto _LRetracar;

    case KDOWNARROW:
      t=(tgmax->v.stextfield.panel_real-tgmin->v.stextfield.panel_real)/4;
      tgmin->v.stextfield.panel_real-=t;
      tgmax->v.stextfield.panel_real-=t;
      goto _LRetracar;

    case '-':
      tgmax->v.stextfield.panel_real =
        2*tgmax->v.stextfield.panel_real-tgmin->v.stextfield.panel_real;
      goto _LRetracar;

    case '+':
      tgmax->v.stextfield.panel_real =
      (tgmax->v.stextfield.panel_real+tgmin->v.stextfield.panel_real)/2;
      goto _LRetracar;

    case MS_LEFT:
      xi=ie_locx;
      yi=ie_locy;
      xf=xi;
      yf=yi;
      selecao=TRUE;
      return;

    case 'E': 
      PlotarEspectro(bpsp);
      return;

    case 'W':
      PlotarEspectro(blsp);
      return;

    default: return;
  }

_LCursor:
  close_window(jpespectro);
  tsp->v.stextfield.panel_real=Frq[fcsr];
  WITH=cfrequencia;
  setwritemode(XOR_PUT);
  setcolor(c_cursor);
  line(colcsr,ymin,colcsr,yfmax);
  colcsr=(short)floor(fcsr*ah+bh+0.5);
  line(colcsr,ymin,colcsr,yfmax);
  setwritemode(COPY_PUT);
  setfillstyle(SOLID_FILL,WITH->back_color);
  bar(0,0,WITH->dx,17);
  moveto(1,1);
  setcolor(cor[1]);
  sprintf(txt,"%10.4f",Frq[fcsr]);
  sprintf(STR1,"Fr:%s",txt);
  outtext(STR1);
  sprintf(txt,"%10.4f",Gan[fcsr]);
  sprintf(STR1," Ga:%s",txt);
  outtext(STR1);
  sprintf(txt,"%9.4f",Ang[fcsr]);
  sprintf(STR1," Ph:%s",txt);
  outtext(STR1);
  if (!plotardesvios) return;
  setcolor(cor[2]);
  moveto(105,9);
  sprintf(txt,"%10.4f",tvar->v.stextfield.panel_real*Dgan[fcsr]);
  sprintf(STR1," Dg:%s",txt);
  outtext(STR1);
  sprintf(txt,"%9.4f",tvar->v.stextfield.panel_real*Dang[fcsr]);
  sprintf(STR1," Dp:%s",txt);
  outtext(STR1);
  return;
_LRecalcular:
  frequencia_valida=FALSE;
_LRetracar:
  AbrirPlotarFrequencia(NULL);
}

short Limx(double x)
{
  double t;

  t=ax*x+bx;
  if (t>xrmax)
    return xrmax;
  else if (t<xmin)
    return xmin;
  else
    return((short)floor(t+0.5));
}

short Limy(double y)
{
  double t;

  t=ay*y+by;
  if (t>yrmax)
    return yrmax;
  else if (t<ymin)
    return ymin;
  else
    return((short)floor(t+0.5));
}

void PlotarPouZ(raizes *R,boolean xis)
{
  short x,y,i,FORLIM;

  FORLIM=R->g;
  for (i=0; i<FORLIM; i++) {
      x=Limx(R->re[i]);
      y=Limy(R->im[i]);
      if (xis) {
          line(x-2,y-2,x+2,y+2);
          line(x-2,y+2,x+2,y-2);
      }
      else
        circle(x,y,4);
  }
}

void PlotarRaizes(Xv_opaque obj)
{
  double x2,y2;

  if (!analise_valida||!(polos_validos||zeros_validos)) {
      if (obj!=craizes)
        Saida("* No roots computed");
      return;
  }
  close_window(jpraizes);
  xrmax=craizes->dx-2;
  yrmax=craizes->dy-11;
  xcursor=-2000;
  ycursor=-2000;
  y2=timmin->v.stextfield.panel_real+tdelta->v.stextfield.panel_real;
  ay=(yrmax-ymin)/(timmin->v.stextfield.panel_real-y2);
  by=yrmax-ay*timmin->v.stextfield.panel_real;
  ax=-ay*fator;
  bx=xmin-ax*tremin->v.stextfield.panel_real;
  x2=(xrmax-bx)/ax;
  IniciarGrafico(craizes,tremin->v.stextfield.panel_real,x2,timmin->v.stextfield.panel_real,
                 y2,xrmax,yrmax,FALSE);
  outtextxy(xmin+2,ymin,"Im");
  outtextxy(xrmax-16,yrmax-8,"Re");
  setcolor(cor[2]);
  circle((short)floor(bx+0.5),(short)floor(by+0.5),
         (short)floor(ax+0.5));
  setcolor(cor[1]);
  if (polos_validos)
    PlotarPouZ(&Polos,TRUE);
  if (zeros_validos)
    PlotarPouZ(&Zeros,FALSE);
}

/* variables for EventosRaizes: */
struct LOC_EventosRaizes {
  double x,y,x1,y1,dist;
} ;

void Testar(raizes *R,boolean saopolos,struct LOC_EventosRaizes *LINK)
{
  double teste;
  short j,FORLIM;

  FORLIM=R->g;
  for (j=1; j<=FORLIM; j++) {
      teste=fabs(LINK->x1-R->re[j-1])+fabs(LINK->y1-R->im[j-1]);
      if (teste<LINK->dist) {
          LINK->dist=teste;
          ok=saopolos;
          LINK->x=R->re[j-1];
          LINK->y=R->im[j-1];
          rcsr=j;
      }
  }
}

void EventosRaizes(Xv_opaque obj)
{
  struct LOC_EventosRaizes V;
  static short xi=0, yi=0, xf=0, yf=0;
  static boolean selecao=FALSE;
  char STR4[256];

  if (!(polos_validos||zeros_validos)) return;
  if (selecao) {
    setwritemode(XOR_PUT);
    setcolor(c_cursor);
    if (ie_code==LOC_DRAG) {
      rectangle(xi,yi,xf,yf);
      yf=ie_locy;
      xf=xi+(short)floor((yi-yf)*ax/ay+0.5);
      rectangle(xi,yi,xf,yf);
      return;
    }
    if (ie_shiftcode==0) {
      selecao=FALSE;
      rectangle(xi,yi,xf,yf);
      if (xi>=xf||yi>=yf)
        return;
      tremin->v.stextfield.panel_real=(xi-bx)/ax;
      timmin->v.stextfield.panel_real=(yf-by)/ay;
      tdelta->v.stextfield.panel_real=(yi-yf)/ay;
      setwritemode(COPY_PUT);
      goto _LReplotar;
    }
  }
  if (ie_code<256) ie_code=toupper(ie_code);
  switch (ie_code) {

    case MS_MIDDLE:
    case LOC_DRAG:
      V.x1=(ie_locx-bx)/ax;
      V.y1=(ie_locy-by)/ay;
      V.dist=1e38;
      if (polos_validos)
        Testar(&Polos,TRUE,&V);
      if (zeros_validos)
        Testar(&Zeros,FALSE,&V);
      setcolor(craizes->fore_color);
      setfillstyle(SOLID_FILL,craizes->back_color);
      bar(0,0,craizes->dx,9);
      moveto(1,1);
      if (ok)
        outtext("Pole");
      else
        outtext("Zero");
      sprintf(STR4," %hd:%*.*f%*.*fj",
         rcsr,8,5,V.x,8,5,V.y);
      outtext(STR4);
      setwritemode(XOR_PUT);
      setcolor(c_cursor);
      rectangle(xcursor-6,ycursor-6,xcursor+6,ycursor+6);
      xcursor=Limx(V.x);
      ycursor=Limy(V.y);
      rectangle(xcursor-6,ycursor-6,xcursor+6,ycursor+6);
      return;

    case KUPARROW:
      timmin->v.stextfield.panel_real+=tdelta->v.stextfield.panel_real/4;
      break;

    case KDOWNARROW:
      timmin->v.stextfield.panel_real-=tdelta->v.stextfield.panel_real/4;
      break;

    case KRIGHTARROW:
      tremin->v.stextfield.panel_real+=tdelta->v.stextfield.panel_real/4;
      break;

    case KLEFTARROW:
      tremin->v.stextfield.panel_real-=tdelta->v.stextfield.panel_real/4;
      break;

    case '-':
      timmin->v.stextfield.panel_real-=tdelta->v.stextfield.panel_real/2;
      tremin->v.stextfield.panel_real-=tdelta->v.stextfield.panel_real/2;
      tdelta->v.stextfield.panel_real*=2;
      break;

    case '+':
      timmin->v.stextfield.panel_real+=tdelta->v.stextfield.panel_real/4;
      tremin->v.stextfield.panel_real+=tdelta->v.stextfield.panel_real/4;
      tdelta->v.stextfield.panel_real/=2;
      break;

    case 'G':
      grade=!grade;
      break;

    case MS_LEFT:
      xi=ie_locx;
      yi=ie_locy;
      xf=xi;
      yf=yi;
      selecao=TRUE;
      return;

   default: return;
  }
_LReplotar:
  PlotarRaizes(NULL);
}

void AbrirRaizes(Xv_opaque obj)
{
  if (!AnaliseValida())
    return;
  close_window(jpraizes);
  CalcularPoloseZeros();
  if (!jraizes->v.sframe.mapped) {
      open_window(jraizes);
      return;
  }
  open_window(jraizes);
  if (xv_ok)
    PlotarRaizes(NULL);
}

void ListarPoloseZeros(Xv_opaque obj)
{
  char STR1[20];

  if (!AnaliseValida())
    return;
  CalcularPoloseZeros();
  if (!polos_validos)
    return;
  ListarRaizes(&Polos,"Denominator");
  if (zeros_validos)
    ListarRaizes(&Zeros,NomeAtual(STR1));
}

double Vin(double t)
{
  switch (sinput->v.ssetting.sel_setting) {

    case 1:
      t=1.0;
      break;

    case 2: /*Usa ht, nao t*/
      if (ht<fases)
        t=1.0;
      else
        t=0.0;
      break;

    case 3:
      t=sin(2*M_PI*tfreq->v.stextfield.panel_real*t+tfase->v.stextfield.panel_real*M_PI/180);
      break;
  }
  return(t*tampl->v.stextfield.panel_real);
}

short Ly_(double x)
{
  double t;

  t=av*x+bv;
  if (t>ytmax)
    t=ytmax;
  else if (t<ymin)
    t=ymin;
  return((short)floor(t+0.5));
}

void PlotarTransiente(Xv_opaque obj)
{
  numeradores Num;
  apontadores Q;
  double w,t,dt;
  short p,m,FORLIM;
  polpequeno *WITH;
  short FORLIM1;
  tiporeftran *WITH1;

  if (!analise_valida) {
      if (obj!=ctransiente)
        Saida("* No analysis made");
      return;
  }
  close_window(jptransiente);
  if (Adjunto()) {
      memcpy(Q,L,sizeof(apontadores));
      memcpy(Num,Apa,sizeof(numeradores));
  }
  else {
      memcpy(Q,C,sizeof(apontadores));
      memcpy(Num,Npa,sizeof(numeradores));
  }
  if (!transiente_valido)
    ultimot=-1;
  if (tsegmt->v.stextfield.panel_int>segmax)
    tsegmt->v.stextfield.panel_int=segmax;
  if (tsegmt->v.stextfield.panel_int<1)
    tsegmt->v.stextfield.panel_int=1;
  ytmax=ctransiente->dy-11;
  xtmax=ctransiente->dx-2;
  av=(ytmax-ymin)/(tvmin->v.stextfield.panel_real-tvmax->v.stextfield.panel_real);
  bv=ytmax-av*tvmin->v.stextfield.panel_real;
  dt=1/(tfs->v.stextfield.panel_real*fases);
  ctcsr=-10; /*para o cursor*/
  at=(double)(xtmax-xmin)/tsegmt->v.stextfield.panel_int;
  bt=xmin;
  IniciarGrafico(ctransiente,0.0,tsegmt->v.stextfield.panel_int*dt,
		 tvmin->v.stextfield.panel_real,tvmax->v.stextfield.panel_real,xtmax,ytmax,
                 FALSE);
  outtextxy(xmin+2,ymin,"Vi,Vo(V)");
  outtextxy(xtmax-32,ytmax-8,"t(s)");
  w=0.0;
  ht=0;
  m=Nden.g*fases;
  tcsr=0;
  do {
      if (ht>ultimot) {
          t=0.0;
          p=ht%fases+1; /*fase atual*/
	  Vi[ht]=Vin(w);
	  if (Q[p-1][tsaida->v.stextfield.panel_int]!=0 &&
	      (stiponum->v.ssetting.sel_setting==2||p==tfj->v.stextfield.panel_int)) {
              for (k=1; k<=fases; k++) {
		  if (stiponum->v.ssetting.sel_setting==2||k==tfk->v.stextfield.panel_int) {
		      WITH=&Num[Q[p-1][tsaida->v.stextfield.panel_int]-1][k-1];
                      FORLIM1=WITH->g;
                      for (i=0; i<=FORLIM1; i++) {
                          j=ht+i*fases-m+WITH->minpot;
                          if (j>=0)
                            t+=WITH->cre[i]*Vi[j];
                      }
                  }
              }
              FORLIM=Nden.g;
              for (i=0; i<FORLIM; i++) {
                  j=ht+i*fases-m;
                  if (j>=0)
                    t-=Nden.cre[i]*Vo[j];
              }
          }
          Vo[ht]=t;
          Tempo[ht]=w;
      }
      if (ht>0) {
          i=(short)floor(at*ht+bt+0.5);
          j=(short)floor(at*(ht-1)+bt+0.5);
          for (k=1; k<=reftran; k++) {
              WITH1=Reft[k-1];
              if (ht<=WITH1->ultimotran) {
                  setcolor(cor[7-k]);
		  setlinestyle(SOLID_LINE,0,NORM_WIDTH);
                  if (WITH1->reftranreter) {
                      moveto(j,Ly_(WITH1->RVo[ht-1]));
                      lineto(i,gety());
                      lineto(i,Ly_(WITH1->RVo[ht]));
                  }
                  else
                    line(i,Ly_(0.0),i,Ly_(WITH1->RVo[ht]));
		  setlinestyle(SOLID_LINE,0,NORM_WIDTH);
              }
          }
	  if (stinput->v.ssetting.sel_setting==1) {
              setcolor(cor[2]);
              moveto(j,Ly_(Vi[ht-1]));
              lineto(i,gety());
              lineto(i,Ly_(Vi[ht]));
          }
          setcolor(cor[1]);
	  if (ssh->v.ssetting.sel_setting==1) {
              moveto(j,Ly_(Vo[ht-1]));
              lineto(i,gety());
              lineto(i,Ly_(Vo[ht]));
          }
          else
            line(i,Ly_(0.0),i,Ly_(Vo[ht]));
      }
      if (kbhit()) {
          if (ht>ultimot)
            ultimot=ht;
          goto _LFim;
      }
      w+=dt;
      ht++;
  } while (ht<=tsegmt->v.stextfield.panel_int);
  ht=tsegmt->v.stextfield.panel_int;
  ultimot=ht;
_LFim:
  transiente_valido=TRUE;
}

void AbrirTransiente(Xv_opaque obj)
{
  if (!AnaliseValida())
    return;
  close_window(jptransiente);
  if (!jtransiente->v.sframe.mapped) {
      open_window(jtransiente);
      return;
  }
  open_window(jtransiente);
  if (xv_ok)
    PlotarTransiente(NULL);
}

void EventosTransiente(Xv_opaque obj)
{
  double t;
  Xv_opaque WITH;
  char STR1[256];

  if (!transiente_valido)
    return;
  if (ie_code<256) ie_code=toupper(ie_code);
  switch (ie_code) {

    case LOC_DRAG:
    case MS_MIDDLE:
      tcsr=(short)floor((ie_locx-bt)/at+0.5);
      if (tcsr<0)
        tcsr=0;
      if (tcsr>ultimot)
        tcsr=ultimot;
      goto _LCursor;

    case 'R':
      tsegmt->v.stextfield.panel_int*=2;
      goto _LRecalcular;

    case 'A':
      tsegmt->v.stextfield.panel_int/=2;
      goto _LRecalcular;

    case KLEFTARROW:
      if (tcsr>=1)
        tcsr--;
      break;

    case KRIGHTARROW:
      if (tcsr<ht)
        tcsr++;
      break;

    case KUPARROW:
      t=(tvmax->v.stextfield.panel_real-tvmin->v.stextfield.panel_real)/4;
      tvmin->v.stextfield.panel_real+=t;
      tvmax->v.stextfield.panel_real+=t;
      goto _LRetracar;

    case KDOWNARROW:
      t=(tvmax->v.stextfield.panel_real-tvmin->v.stextfield.panel_real)/4;
      tvmin->v.stextfield.panel_real-=t;
      tvmax->v.stextfield.panel_real-=t;
      goto _LRetracar;

    case '-':
      tvmax->v.stextfield.panel_real =
        2*tvmax->v.stextfield.panel_real-tvmin->v.stextfield.panel_real;
      goto _LRetracar;

    case '+':
      tvmax->v.stextfield.panel_real =
        (tvmax->v.stextfield.panel_real+tvmin->v.stextfield.panel_real)/2;
      goto _LRetracar;

    case 'G':
      grade=!grade;
      goto _LRetracar;

    default: return;
  }
_LCursor:
  WITH=ctransiente;
  setwritemode(XOR_PUT);
  setcolor(c_cursor);
  line(ctcsr,ymin,ctcsr,ytmax);
  ctcsr=(short)floor(tcsr*at+bt+0.5);
  line(ctcsr,ymin,ctcsr,ytmax);
  setwritemode(COPY_PUT);
  setfillstyle(SOLID_FILL,WITH->back_color);
  bar(0,0,WITH->dx,17);
  moveto(1,1);
  setcolor(cor[1]);
  sprintf(txt,"%9.5f",Tempo[tcsr]);
  sprintf(STR1,"t:%s",txt);
  outtext(STR1);
  sprintf(txt,"%hd",tcsr%fases+1);
  sprintf(STR1," p:%s",txt);
  outtext(STR1);
  sprintf(txt,"%8.5f",Vo[tcsr]);
  sprintf(STR1," Vo:%s",txt);
  outtext(STR1);
  sprintf(txt,"%8.5f",Vi[tcsr]);
  sprintf(STR1," Vi:%s",txt);
  outtext(STR1);
  return;
_LRecalcular:
  transiente_valido=FALSE;
_LRetracar:
  PlotarTransiente(NULL);
}

void AbrirJNetlist(Xv_opaque obj)
{
  open_window(jdiretorio);
  open_window(jnetlist);
}

void TratarMenu1(Xv_opaque obj)
{
  char STR1[256];

  switch (obj->v.smenu.sel_menu) {

    case 1:
      AbrirJNetlist(NULL);
      break;

    case 2:
      open_window(jpanalise);
      break;

    case 3:
      ListarDenominador();
      break;

    case 4:
      open_window(jpnumerador);
      break;

    case 5:
      open_window(jpraizes);
      break;

    case 6:
      open_window(jpfrequencia);
      break;

    case 7:
      open_window(jptransiente);
      break;

    case 8:
      open_window(jterminal);
      break;

    case 9:
      sprintf(STR1,"X_ASIZ - version %s",versao);
      Saida(STR1);
      Saida("Z-domain analysis of switched-current filters");
      Saida("By: Antonio Carlos Moreirao de Queiroz");
      Saida("COPPE/EE\n\rUniversidade Federal do Rio de Janeiro");
      Saida("CP 68504\n\rCEP 21945-970, Rio de Janeiro, RJ, Brasil");
      Saida("e-mail: acmq@coe.ufrj.br");
      sprintf(STR1,"Limits:\n\rNodes=%d, Elements=%d\n\rPhases=%d, Equations=%d",nosmax,elmax,fasmax,linmax);
      Saida(STR1);
      sprintf(STR1,"free memory: %lu bytes\n\r",coreleft());
      Saida(STR1);
      break;

    case 10:
      open_window(jdiretorio);
      break;

    case 11:
      open_window(jmos);
      break;

    case 12:
      open_window(jsensi);
      if (tnsaida->v.stextfield.panel_int!=tsaida->v.stextfield.panel_int) {
          Saida("* Deviations not available for the current output node");
          open_window(jpanalise);
      }
      break;

    case 13:
      open_window(jpespectro);
      break;

    case 14:
      Back();
      break;

    case 15:
      xv_end=1;
      break;
  }
}

void ListarNumerador(Xv_opaque obj)
{
  char STR1[256];
  char STR2[256],STR3[256];

  if (!AnaliseValida())
    return;
  switch (stiponum->v.ssetting.sel_setting) {

    case 1:
      sprintf(STR3,"Partial numerator %s:",NomeAtual(STR1));
      Saida(STR3);
      if (Adjunto()) {
	  k=L[tfj->v.stextfield.panel_int-1][tsaida->v.stextfield.panel_int];
          if (k!=0)
	    ListarPequeno(&Apa[k-1][tfk->v.stextfield.panel_int-1]);
          else
            Saida("Zero");
      }
      else {
	  k=C[tfj->v.stextfield.panel_int-1][tsaida->v.stextfield.panel_int];
          if (k!=0)
	    ListarPequeno(&Npa[k-1][tfk->v.stextfield.panel_int-1]);
          else
            Saida("Zero");
      }
      break;

    case 2:
      sprintf(STR2,"Global numerator %s:",NomeAtual(STR1));
      Saida(STR2);
      GerarGlobal();
      ListarGrande();
      break;
  }
}

void TratarMenuPlot(Xv_opaque obj)
{
  tiporeffreq *WITH;
  char STR2[256],STR3[256];
  tiporeftran *WITH1;
  char STR5[82];

  switch (obj->v.smenu.sel_menu) {

    case 1:
      if (active_w==jfrequencia) {
	  if (frequencia_valida) {
	      if (reffreq<refmax) {
		if ((Reff[reffreq]=malloc(sizeof(tiporeffreq)))!=0) {
		  reffreq++;
		  WITH=Reff[reffreq-1];
		  WITH->Rnglobal=Nglobal;
		  WITH->Rden=Nden;
                  if ((WITH->Rden.cre=malloc(sizepoly))!=0) {
                    memcpy(WITH->Rden.cre,Nden.cre,sizepoly);
                    WITH->reffases=fases;
		    memcpy(WITH->Rgan,Gan,sizeof(grafico));
		    memcpy(WITH->Rang,Ang,sizeof(grafico));
		    WITH->reffreqreter=(ssh->v.ssetting.sel_setting==1);
		    sprintf(STR3,"Frequency response reference #%hd saved",reffreq);
		    Saida(STR3);
                  }
                  else {
                    reffreq--;
                    free(Reff[reffreq]);
                    Saida("* Not enough memory");
                  }
		}
		else
		  Saida("* Not enough memory");
	     }
	     else
	       Saida("* Too many references");
	  }
	  else
	    Saida("* Nothing to save");
      }
      else if (active_w==jtransiente) {
	  if (transiente_valido) {
	      if (reftran<refmax) {
		if ((Reft[reftran]=malloc(sizeof(tiporeftran)))!=0) {
		  reftran++;
		  WITH1=Reft[reftran-1];
		  memcpy(WITH1->RVo,Vo,sizeof(grafico));
		  WITH1->reftranreter=(ssh->v.ssetting.sel_setting==1);
		  WITH1->ultimotran=ultimot;
		  sprintf(STR2,"Transient response reference #%hd saved",
			  reftran);
		  Saida(STR2);
		}
		else
		  Saida(" Not enough memory");
	      }
	      else
		Saida("* Too many references");
	  }
	  else
	    Saida("* Nothing to save");
      }
      else
	Saida("* Not implemented");
      break;

    case 2:
      if (active_w==jfrequencia) {
          if (reffreq>0) {
              free(Reff[reffreq-1]->Rden.cre);
	      free(Reff[reffreq-1]);
              reffreq--;
              AbrirPlotarFrequencia(NULL);
	      setlinestyle(SOLID_LINE,0,NORM_WIDTH);
              /*senao pode ficar dottedln*/
	      sprintf(STR3,"Frequency response reference #%hd eliminated",reffreq+1);
              Saida(STR3);
          }
          else
            Saida("* No reference saved");
      }
      else if (active_w==jtransiente) {
          if (reftran>0) {
              free(Reft[reftran-1]);
              reftran--;
              PlotarTransiente(NULL);
	      sprintf(STR2,"Transient response reference #%hd eliminated",reftran+1);
              Saida(STR2);
          }
          else
            Saida("* No reference saved");
      }
      else
        Saida("* Not implemented");
      break;

    case 3:
      if (active_w==jfrequencia) {
          if (frequencia_valida) {
              if (relatorio)
                EscreverTabelaFrequencia();
              else
                AbrirJRelatorio(frequencia);
          }
          else
            Saida("* Nothing to save");
      }
      else if (active_w==jtransiente) {
          if (transiente_valido) {
              if (relatorio)
                EscreverTabelaTransiente();
              else
                AbrirJRelatorio(transiente);
          }
          else
            Saida("* Nothing to save");
      }
      else
        Saida("* Save the messages listing");
      break;

    case 4:
      if (relatorio) {
          fclose(arquivo);
	  sprintf(STR5,"Report file %s closed",trelatorio->v.stextfield.panel_value);
          Saida(STR5);
          relatorio=FALSE;
      }
      else
        Saida("* No report file open");
      break;

    case 5:
      if (active_w==jfrequencia)
        open_window(jpfrequencia);
      else if (active_w==jtransiente)
        open_window(jptransiente);
      else
        open_window(jpraizes);
      break;
  }
}

void SetarSaida(Xv_opaque obj)
{
  tsaida->v.stextfield.panel_int=tnsaida->v.stextfield.panel_int;
  InvalidarAnalise(NULL);
}

void AbrirRelatorio(Xv_opaque obj)
{
  time_t t;
  close_window(jrelatorio);
  arquivo=fopen(trelatorio->v.stextfield.panel_value,"w");
  time(&t);
  ioresult=fprintf(arquivo,"X_ASIZ *====* Version %s *====* %s",
	   versao,ctime(&t));
  ioresult=fprintf(arquivo,"\nTitle: %s\n",rede);
  ioresult=fprintf(arquivo,"\nNodes: %hd; Phases: %hd\n",nos,fases);
  relatorio=(ioresult!=EOF);
  if (!relatorio) {
    Falha();
    return;
  }
  switch (asalvar) {

    case frequencia:
      EscreverTabelaFrequencia();
      break;

    case transiente:
      EscreverTabelaTransiente();
      break;

    case mensagens:
      EscreverMensagens();
      break;
  }
}

void TratarMenuMsg(Xv_opaque obj)
{
  Xv_opaque WITH;

  WITH=ttymsg;
  switch (obj->v.smenu.sel_menu) {

    case 1:
      WITH->v.stty.bstart=0;
      WITH->v.stty.tstart=0;
      WITH->v.stty.tend=0;
      ttysw_output(ttymsg,"");
      break;

    case 2:
      if (relatorio)
        EscreverMensagens();
      else
        AbrirJRelatorio(mensagens);
      break;
  }
}

void LerDiretorio(Xv_opaque obj)
{

  struct ffblk srec;
  short done;

  settextstyle(SMALL_FONT,HORIZ_DIR,4);
  if (obj!=cdiretorio) {
    setfillstyle(SOLID_FILL,cdiretorio->back_color);
    bar(0,0,cdiretorio->dx,cdiretorio->dy);
  }
  nomes=cdiretorio->dx/78;
  total=0;
  done=findfirst(tmask->v.stextfield.panel_value,&srec,0);
  while (!done) {
    outtextxy(total%nomes*78+3,total/nomes*8,srec.ff_name);
    done=findnext(&srec);
    total++;
  }
  total--;
}

void EscolherArquivo(Xv_opaque obj)
{
  struct ffblk srec;
  char drive[MAXDRIVE];
  char dir[MAXDIR];
  char file[MAXFILE];
  char ext[MAXEXT];
  short i,k,done;

  if (ie_code!=MS_LEFT)
    return;
  k=(ie_locx-3)/78;
  if (k>=nomes)
    return;
  k+=(ie_locy-3)/8*nomes;
  if (k>total)
    return;
  i=0;
  done=findfirst(tmask->v.stextfield.panel_value,&srec,0);
  while ((!done)&&(i<k)) {
    done=findnext(&srec);
    i++;
  }
  fnsplit(tmask->v.stextfield.panel_value,drive,dir,file,ext);
  sprintf(tnetlist->v.stextfield.panel_value,"%s%s%s",drive,dir,srec.ff_name);
  xv_set(tnetlist,tnetlist->xv_label);
}

void LerGrupos(Xv_opaque obj)
{
  char STR1[256],STR2[256];
  _REC_NetList *WITH;
  char *TEMP;
  FILE *arquivo;

  if (!netlist_valido)
    return;
  close_window(jsensi);
  sprintf(STR1,"%s%s",rede,sg);
  arquivo=fopen(STR1,"r");
  if (arquivo==NULL) {
      sprintf(STR2,"* File %s%s not found",rede,sg);
      Saida(STR2);
      return;
  }
 /*ReadLn(arquivo,sdesvios^.sel_setting,tvar^.panel_real);*/
  e=0;
  ok=TRUE;
  while (e<elementos&&ok) {
      e++;
      WITH=&NetList[e-1];
      WITH->grupo=getc(arquivo);
      ch=getc(arquivo);
      fgets(txt,256,arquivo);
      TEMP=strchr(txt,'\n');
      if (TEMP!=NULL)
        *TEMP=0;
      WITH->selecionado=(ch=='+');
      ok=(strcmp(txt,WITH->nome)==0);
  }
  if (ok) {
      sprintf(STR2,"Selection read from file %s%s",rede,sg);
      Saida(STR2);
  }
  else {
      sprintf(STR2,"* The file %s%s does not correspond to the netlist",
              rede,sg);
      Saida(STR2);
  }
  fclose(arquivo);
  open_window(jsensi);
  frequencia_valida=FALSE;
}

void EscreverGrupos(Xv_opaque obj)
{
  FILE *arquivo;

  /* !!! Notar que as operacoes com arquivo nao sao testadas */
  char STR1[256],STR2[256];
  _REC_NetList *WITH;

  if (!netlist_valido)
    return;
  sprintf(STR1,"%s%s",rede,sg);
  arquivo=fopen(STR1,"w");
 /*WriteLn(arquivo,sdesvios^.sel_setting,' ',tvar^.panel_real);*/
  for (e=1; e<=elementos; e++) {
      WITH=&NetList[e-1];
      if (WITH->selecionado)
	ch='+';
      else
	ch='-';
      fprintf(arquivo,"%c%c%s\n",WITH->grupo,ch,WITH->nome);
  }
  fclose(arquivo);
  sprintf(STR2,"Selection saved on file %s%s",rede,sg);
  Saida(STR2);
}

void set_default(void)
{
  w_base->v.sframe.mouse_obj=o_base;
}

void main(int argc,char *argv[])
{
  char STR1[256];

  arquivo=NULL;
  normal=TRUE;
  plotarfase=TRUE;
  reffreq=0;
  reftran=0;
  relatorio=FALSE;
  Frq=malloc(sizeof(grafico));
  Gan=malloc(sizeof(grafico));
  Ang=malloc(sizeof(grafico));
  Tempo=malloc(sizeof(grafico));
  Vi=malloc(sizeof(grafico));
  Vo=malloc(sizeof(grafico));
  Dgan=malloc(sizeof(grafico));
  assert((Dang=malloc(sizeof(grafico)))!=0);
  placa=0;
  modo=0;
  if (argc==4) {
      i=(sscanf(strcpy(STR1,argv[2]),"%hd",&placa)==0);
      i=(sscanf(strcpy(STR1,argv[3]),"%hd",&modo)==0);
  }
  xv_init(placa,modo);
  if (getmaxcolor()==1)
    memcpy(cor,cormono,sizeof(cores));
  getaspectratio((int far*)(&xasp),(int far*)(&yasp));
  fator=(double)yasp/xasp;
  normal_bsize=10000;
  menu1=xv_create(NULL,MENU,
    XV_LABEL,"Main menu:",
    ITEM_MENU,"netlist","analysis","denominator",
      "numerator","poles and zeros","frequency response",
      "transient response","messages","informations",
      "directory","mosfet parameters","sensitivity",
      "output spectrum",
      "back","quit",
    NULL,
    NOTIFY_HANDLER,TratarMenu1,
    SEL_MENU,6,
    NULL);
  menuplot=xv_create(NULL,MENU,
    XV_LABEL,"Plot menu:",
    ITEM_MENU,"save as reference","delete reference","save in report file",
      "close report file","parameters",
    NULL,
    NOTIFY_HANDLER,TratarMenuPlot,
    NULL);
  menumsg=xv_create(NULL,MENU,
    XV_LABEL,"Msg menu",
    ITEM_MENU,"Clear messages","Save in report",NULL,
    NOTIFY_HANDLER,TratarMenuMsg,
    NULL);
  jterminal=xv_create(NULL,FRAME,
    XV_LABEL,"Messages",
    DX,319,
    DY,239,
    X,320,
    MENU_NAME,menu1,
    NULL);
  ttymsg=xv_create(jterminal,TTY,
    MENU_NAME,menumsg,
    NULL);
  jfrequencia=xv_create(NULL,FRAME,
    DX,getmaxx(),
    DY,getmaxy(),
    XV_LABEL,"X_ASIZ",
    MENU_NAME,menu1,
    ADJUST_EXIT,FALSE,
    NULL);
  cfrequencia=xv_create(jfrequencia,CANVAS,
    FORE_COLOR,c_white,
    BACK_COLOR,c_black,
    MENU_NAME,menuplot,
    NOTIFY_HANDLER,AbrirPlotarFrequencia,
    EVENT_HANDLER,EventosFrequencia,
    NULL);
  jraizes=xv_create(NULL,FRAME,
    DX,319,
    DY,239,
    XV_LABEL,"Poles and Zeros",
    MENU_NAME,menu1,
    Y,240,
    NULL);
  craizes=xv_create(jraizes,CANVAS,
    FORE_COLOR,c_white,
    BACK_COLOR,c_black,
    MENU_NAME,menuplot,
    NOTIFY_HANDLER,PlotarRaizes,
    EVENT_HANDLER,EventosRaizes,
    NULL);
  jtransiente=xv_create(NULL,FRAME,
    DX,319,
    DY,239,
    XV_LABEL,"Transient Response",
    MENU_NAME,menu1,
    X,320,
    Y,240,
    NULL);
  ctransiente=xv_create(jtransiente,CANVAS,
    FORE_COLOR,c_white,
    BACK_COLOR,c_black,
    MENU_NAME,menuplot,
    NOTIFY_HANDLER,PlotarTransiente,
    EVENT_HANDLER,EventosTransiente,
    NULL);
  normal_length=20;
  jpfrequencia=xv_create(NULL,FRAME,
    MENU_NAME,menu1,
    DX,319,
    DY,144,
    X,100,
    Y,100,
    XV_LABEL,"Frequency Response Parameters",
    NULL);
  twmin=xv_create(jpfrequencia,TEXTFIELD,
    XV_LABEL,"Minimum frequency",
    FIELD_TYPE,real_field,
    PANEL_REAL,"0.2",
    NOTIFY_HANDLER,InvalidarFrequencia,
    NULL);
  twmax=xv_create(jpfrequencia,TEXTFIELD,
    XV_LABEL,"Maximum frequency",
    FIELD_TYPE,real_field,
    PANEL_REAL,"5.0",
    Y,15,
    NOTIFY_HANDLER,InvalidarFrequencia,
    NULL);
  tgmin=xv_create(jpfrequencia,TEXTFIELD,
    XV_LABEL,"Minimum gain",
    FIELD_TYPE,real_field,
    PANEL_REAL,"-80.0",
    Y,30,
    NULL);
  tgmax=xv_create(jpfrequencia,TEXTFIELD,
    XV_LABEL,"Maximum gain",
    FIELD_TYPE,real_field,
    PANEL_REAL,"10.0",
    Y,45,
    NULL);
  slog=xv_create(jpfrequencia,SETTING,
    ITEM_SETTING,"log","linear",NULL,
    XV_LABEL,"Scale",
    SEL_SETTING,1,
    EXCLUSIVE,TRUE,
    Y,60,
    NOTIFY_HANDLER,InvalidarFrequencia,
    NULL);
  srads=xv_create(jpfrequencia,SETTING,
    ITEM_SETTING,"rad/s","Hertz",NULL,
    XV_LABEL,"Frequency unit",
    SEL_SETTING,1,
    EXCLUSIVE,TRUE,
    Y,75,
    NOTIFY_HANDLER,InvalidarFrequencia,
    NULL);
  normal_length=7;
  tsegmf=xv_create(jpfrequencia,TEXTFIELD,
    XV_LABEL,"Segments",
    FIELD_TYPE,int_field,
    PANEL_INT,199,
    MIN_VALUE,1,
    MAX_VALUE,segmax,
    Y,90,
    NOTIFY_HANDLER,InvalidarFrequencia,
    NULL);
  brf=xv_create(jpfrequencia,BUTTON,
    XV_LABEL,"Plot",
    NOTIFY_HANDLER,AbrirPlotarFrequencia,
    Y,105,
    NULL);
  set_default();
  jpespectro=xv_create(NULL,FRAME,
    X,150,
    Y,150,
    DX,319,
    DY,55,
    DYMIN,55,
    XV_LABEL,"Output Spectrum Parameters",
    NULL);
  tsp=xv_create(jpespectro,TEXTFIELD,
    XV_LABEL,"Input frequency",
    PANEL_REAL,"1.0",
    FIELD_TYPE,real_field,
    VALUE_LENGTH,20,
    NULL);
  bpsp=xv_create(jpespectro,BUTTON,
    XV_LABEL,"Plot",
    NOTIFY_HANDLER,PlotarEspectro,
    Y,15,
    NULL);
  set_default();
  blsp=xv_create(jpespectro,BUTTON,
    XV_LABEL,"List",
    Y,15,X,42,
    NOTIFY_HANDLER,PlotarEspectro,
    NULL);
  jptransiente=xv_create(NULL,FRAME,
    MENU_NAME,menu1,
    DX,319,
    DY,144,
    X,200,
    Y,200,
    XV_LABEL,"Transient Response Parameters",
    NULL);
  normal_length=20;
  tvmin=xv_create(jptransiente,TEXTFIELD,
    XV_LABEL,"Minimum voltage",
    FIELD_TYPE,real_field,
    PANEL_REAL,"-1.0",
    NULL);
  tvmax=xv_create(jptransiente,TEXTFIELD,
    XV_LABEL,"Maximum voltage",
    FIELD_TYPE,real_field,
    PANEL_REAL,"3.0",
    Y,15,
    NULL);
  tsegmt=xv_create(jptransiente,TEXTFIELD,
    XV_LABEL,"Phase steps",
    FIELD_TYPE,int_field,
    PANEL_INT,79,
    MIN_VALUE,1,
    VALUE_LENGTH,7,
    MAX_VALUE,segmax,
    Y,30,
    NOTIFY_HANDLER,InvalidarTransiente,
    NULL);
  sinput=xv_create(jptransiente,SETTING,
    ITEM_SETTING,"step","impulse","sinusoid",NULL,
    XV_LABEL,"Input",
    EXCLUSIVE,TRUE,
    SEL_SETTING,1,
    Y,45,
    NOTIFY_HANDLER,InvalidarTransiente,
    NULL);
  stinput=xv_create(jptransiente,SETTING,
    XV_LABEL,"Plot",
    X,216,
    Y,45,
    ITEM_SETTING,"yes","no",NULL,
    EXCLUSIVE,TRUE,
    SEL_SETTING,1,
    NULL);
  tampl=xv_create(jptransiente,TEXTFIELD,
    FIELD_TYPE,real_field,
    PANEL_REAL,"1.0",
    XV_LABEL,"Amplitude (A)",
    Y,60,
    NOTIFY_HANDLER,InvalidarTransiente,
    NULL);
  tfreq=xv_create(jptransiente,TEXTFIELD,
    FIELD_TYPE,real_field,
    PANEL_REAL,"0.1",
    XV_LABEL,"Sin freq. (Hz)",
    Y,75,
    NOTIFY_HANDLER,InvalidarTransiente,
    NULL);
  tfase=xv_create(jptransiente,TEXTFIELD,
    FIELD_TYPE,real_field,
    XV_LABEL,"Sin phase",
    Y,90,
    NOTIFY_HANDLER,InvalidarTransiente,
    NULL);
  brt=xv_create(jptransiente,BUTTON,
    XV_LABEL,"Plot",
    NOTIFY_HANDLER,AbrirTransiente,
    Y,105,
    NULL);
  set_default();
  jpraizes=xv_create(NULL,FRAME,
    MENU_NAME,menu1,
    XV_LABEL,"Poles and Zeros Parameters",
    DX,319,
    DY,144,
    X,300,
    Y,300,
    NULL);
  ttolz=xv_create(jpraizes,TEXTFIELD,
    XV_LABEL,"Error tolerance",
    FIELD_TYPE,real_field,
    PANEL_REAL,"1e-11",
    NOTIFY_HANDLER,InvalidarRaizes,
    NULL);
  ttolp=xv_create(jpraizes,TEXTFIELD,
    XV_LABEL,"Magnitude tol. ",
    FIELD_TYPE,real_field,
    PANEL_REAL,"1e-11",
    NOTIFY_HANDLER,InvalidarRaizes,
    Y,15,
    NULL);
  treal=xv_create(jpraizes,TEXTFIELD,
    XV_LABEL,"Real approx.",
    FIELD_TYPE,real_field,
    PANEL_REAL,"0.9",
    Y,30,
    NOTIFY_HANDLER,InvalidarRaizes,
    NULL);
  timag=xv_create(jpraizes,TEXTFIELD,
    XV_LABEL,"Imag approx.",
    FIELD_TYPE,real_field,
    PANEL_REAL,"0.1",
    Y,45,
    NOTIFY_HANDLER,InvalidarRaizes,
    NULL);
  tremin=xv_create(jpraizes,TEXTFIELD,
    XV_LABEL,"Plot real minimum",
    FIELD_TYPE,real_field,
    PANEL_REAL,"-2.0",
    Y,60,
    NULL);
  timmin=xv_create(jpraizes,TEXTFIELD,
    XV_LABEL,"Plot imag minimum",
    FIELD_TYPE,real_field,
    PANEL_REAL,"-2.0",
    Y,75,
    NULL);
  tdelta=xv_create(jpraizes,TEXTFIELD,
    XV_LABEL,"Plot height",
    FIELD_TYPE,real_field,
    PANEL_REAL,"4.0",
    Y,90,
    NULL);
  blist=xv_create(jpraizes,BUTTON,
    XV_LABEL,"List",
    Y,105,
    NOTIFY_HANDLER,ListarPoloseZeros,
    NULL);
  bplot=xv_create(jpraizes,BUTTON,
    XV_LABEL,"Plot",
    Y,105,
    X,45,
    NOTIFY_HANDLER,AbrirRaizes,
    NULL);
  set_default();
  jnetlist=xv_create(NULL,FRAME,
    XV_LABEL,"Netlist File",
    DX,255,
    Y,23,
    DY,55,
    DYMIN,55,
    X,6,
    MENU_NAME,menu1,
    NULL);
  tnetlist=xv_create(jnetlist,TEXTFIELD,
    XV_LABEL,"Filename",
    VALUE_LENGTH,21,
    NULL);
  set_default();
  if (argc>1) {
    strcpy(tnetlist->v.stextfield.panel_value,argv[1]);
  }
  normal_length=7;
  tfases=xv_create(jnetlist,TEXTFIELD,
    XV_LABEL,"Number of phases",
    FIELD_TYPE,int_field,
    PANEL_INT,2,
    MIN_VALUE,1,
    MAX_VALUE,fasmax,
    Y,15,
    NULL);
  bread=xv_create(jnetlist,BUTTON,
    XV_LABEL,"Read",
    Y,15,
    X,204,
    NOTIFY_HANDLER,LerNetList,
    NULL);
  jpanalise=xv_create(NULL,FRAME,
    MENU_NAME,menu1,
    DX,319,
    DY,144,
    XV_LABEL,"Analysis and Sampling Parameters",
    NULL);
  tnsaida=xv_create(jpanalise,TEXTFIELD,
    XV_LABEL,"Output node for sensitivity",
    VALUE_LENGTH,7,
    FIELD_TYPE,int_field,
    PANEL_INT,1,
    NOTIFY_HANDLER,SetarSaida,
    NULL);
  traio=xv_create(jpanalise,TEXTFIELD,
    XV_LABEL,"Interpolation circle radius",
    FIELD_TYPE,real_field,
    PANEL_REAL,"1.1",
    Y,15,
    NOTIFY_HANDLER,InvalidarAnalise,
    NULL);
  tdisp=xv_create(jpanalise,TEXTFIELD,
    XV_LABEL,"Polynomial dispersion factor",
    FIELD_TYPE,real_field,
    PANEL_REAL,"1e6",
    Y,30,
    NOTIFY_HANDLER,InvalidarAnalise,
    NULL);
  tminimo=xv_create(jpanalise,TEXTFIELD,
    XV_LABEL,"Minimum non zero value",
    FIELD_TYPE,real_field,
    PANEL_REAL,"1e-10",
    Y,45,
    NOTIFY_HANDLER,InvalidarAnalise,
    NULL);
  tgrau=xv_create(jpanalise,TEXTFIELD,
    XV_LABEL,"Estimated complexity order",
    FIELD_TYPE,int_field,
    MIN_VALUE,0,
    Y,60,
    NOTIFY_HANDLER,InvalidarAnalise,
    NULL);
  tfs=xv_create(jpanalise,TEXTFIELD,
    XV_LABEL,"Sampling frequency (Hz)",
    FIELD_TYPE,real_field,
    PANEL_REAL,"1.0",
    VALUE_LENGTH,13,
    Y,75,
    NOTIFY_HANDLER,InvalidarFrequencia,
    NULL);
  ssh=xv_create(jpanalise,SETTING,
    ITEM_SETTING,"S/H","impulse",NULL,
    XV_LABEL,"Output sampling",
    SEL_SETTING,1,
    EXCLUSIVE,TRUE,
    Y,90,
    NOTIFY_HANDLER,InvalidarFrequencia,
    NULL);
  banalisar=xv_create(jpanalise,BUTTON,
    XV_LABEL,"Analyze",
    NOTIFY_HANDLER,AnalisarCircuito,
    Y,105,
    NULL);
  set_default();
  jpnumerador=xv_create(NULL,FRAME,
    XV_LABEL,"Numerator Parameters",
    DX,319,
    DY,115,
    MENU_NAME,menu1,
    NULL);
  tsaida=xv_create(jpnumerador,TEXTFIELD,
    XV_LABEL,"Output node",
    FIELD_TYPE,int_field,
    MIN_VALUE,1, /*MAX_VALUE setado em LerNetList*/
    PANEL_INT,1,
    NOTIFY_HANDLER,InvalidarNumerador,
    NULL);
  stiponum=xv_create(jpnumerador,SETTING,
    XV_LABEL,"Type",
    ITEM_SETTING,"Partial","Global",NULL,
    EXCLUSIVE,TRUE,
    SEL_SETTING,2,
    Y,15,
    NOTIFY_HANDLER,InvalidarNumerador,
    NULL);
  tfk=xv_create(jpnumerador,TEXTFIELD,
    XV_LABEL,"Partial numerator input phase ",
    FIELD_TYPE,int_field,
    MIN_VALUE,1, /*Maximo setado por LerNetList*/
    PANEL_INT,1,
    Y,30,
    NOTIFY_HANDLER,InvalidarNumerador,
    NULL);
  tfj=xv_create(jpnumerador,TEXTFIELD,
    XV_LABEL,"Partial numerator output phase",
    FIELD_TYPE,int_field,
    MIN_VALUE,1, /*Idem*/
    PANEL_INT,1,
    Y,45,
    NOTIFY_HANDLER,InvalidarNumerador,
    NULL);
  sadjunto=xv_create(jpnumerador,SETTING,
    XV_LABEL,"Network",
    ITEM_SETTING,"normal","adjoint",NULL,
    SEL_SETTING,1,
    Y,60,
    EXCLUSIVE,TRUE,
    NOTIFY_HANDLER,InvalidarNumerador,
    NULL);
  blistnum=xv_create(jpnumerador,BUTTON,
    XV_LABEL,"List",
    Y,75,
    NOTIFY_HANDLER,ListarNumerador,
    NULL);
  set_default();
  jsensi=xv_create(NULL,FRAME,
    XV_LABEL,"Sensitivity Analysis Parameters",
    DX,319,
    DY,239,
    MENU_NAME,menu1,
    NULL);
  ssensi=xv_create(jsensi,SETTING,
    XV_LABEL,"Do sensitivity analysis",
    ITEM_SETTING,"yes","no",NULL,
    SEL_SETTING,2,
    EXCLUSIVE,TRUE,
    NOTIFY_HANDLER,InvalidarDesvios,
    NULL);
  sdesvios=xv_create(jsensi,SETTING,
    ITEM_SETTING,"statistic","deterministic",NULL,
    XV_LABEL,"Deviation",
    EXCLUSIVE,TRUE,
    SEL_SETTING,1,
    Y,15,
    NOTIFY_HANDLER,InvalidarFrequencia,
    NULL);
  tvar=xv_create(jsensi,TEXTFIELD,
    XV_LABEL,"Variability",
    FIELD_TYPE,real_field,
    PANEL_REAL,"0.05",
    Y,30,
    NULL);
  brsensi=xv_create(jsensi,BUTTON,
    XV_LABEL,"Read",
    X,273,
    NOTIFY_HANDLER,LerGrupos,
    NULL);
  bwsensi=xv_create(jsensi,BUTTON,
    XV_LABEL,"Write",
    X,265,
    Y,15,
    NOTIFY_HANDLER,EscreverGrupos,
    NULL);
  csensi=xv_create(jsensi,CANVAS,
    NOTIFY_HANDLER,DesenharSensi,
    EVENT_HANDLER,MudarElementos,
    Y,45,
    NULL);
  set_default();
  jrelatorio=xv_create(NULL,FRAME,
    XV_LABEL,"Report File",
    X,100,
    Y,100,
    DX,255,
    DY,60,
    DYMIN,60,
    NULL);
  trelatorio=xv_create(jrelatorio,TEXTFIELD,
    XV_LABEL,"Filename",
    VALUE_LENGTH,21,
    NULL);
  brelatorio=xv_create(jrelatorio,BUTTON,
    Y,15,
    XV_LABEL,"Open",
    NOTIFY_HANDLER,AbrirRelatorio,
    NULL);
  set_default();
  jdiretorio=xv_create(NULL,FRAME,
    XV_LABEL,"Directory",
    DX,255,
    X,6,
    Y,79,
    DY,159,
    MENU_NAME,menu1,
    NULL);
  tmask=xv_create(jdiretorio,TEXTFIELD,
    XV_LABEL,"Mask",
    VALUE_LENGTH,24,
    PANEL_VALUE,"*.net",
    NOTIFY_HANDLER,LerDiretorio,
    NULL);
  set_default();
  cdiretorio=xv_create(jdiretorio,CANVAS,
    Y,15,
    NOTIFY_HANDLER,LerDiretorio,
    EVENT_HANDLER,EscolherArquivo,
    NULL);
  jmos=xv_create(NULL,FRAME,
    XV_LABEL,"MOSFET Parameters",
    X,64,
    Y,63,
    DX,255,
    DY,101,
    DYMIN,55,
    MENU_NAME,menu1,
    NOTIFY_HANDLER,AbrirJNetlist,
    NULL);
  scap=xv_create(jmos,SETTING,
    XV_LABEL,"Cgs,Cgd",
    ITEM_SETTING,"1,0","proportional to Gm",NULL,
    EXCLUSIVE,TRUE,
    SEL_SETTING,1,
    NOTIFY_HANDLER,InvalidarNetlist,
    NULL);
  tcgs=xv_create(jmos,TEXTFIELD,
    XV_LABEL,"Cgs for Gm,1",
    Y,15,
    VALUE_LENGTH,6,
    FIELD_TYPE,real_field,
    PANEL_REAL,"1.0",
    NOTIFY_HANDLER,InvalidarNetlist,
    NULL);
  tcgd=xv_create(jmos,TEXTFIELD,
    XV_LABEL,"Cgd for Gm,1",
    Y,30,
    VALUE_LENGTH,6,
    FIELD_TYPE,real_field,
    PANEL_REAL,"1e-2",
    NOTIFY_HANDLER,InvalidarNetlist,
    NULL);
  sgds=xv_create(jmos,SETTING,
    XV_LABEL,"Gds",
    Y,45,
    ITEM_SETTING,"as read","proportional to Gm",NULL,
    EXCLUSIVE,TRUE,
    SEL_SETTING,1,
    NOTIFY_HANDLER,InvalidarNetlist,
    NULL);
  tgds=xv_create(jmos,TEXTFIELD,
    XV_LABEL,"Gds for Gm,1",
    Y,60,
    VALUE_LENGTH,6,
    FIELD_TYPE,real_field,
    PANEL_REAL,"1e-2",
    NOTIFY_HANDLER,InvalidarNetlist,
    NULL);
  open_window(jfrequencia);
  open_window(jdiretorio);
  xv_main_loop(jnetlist);
  restorecrtmode();
  if (relatorio) fclose(arquivo);
  exit(0);
}

/* End. */
