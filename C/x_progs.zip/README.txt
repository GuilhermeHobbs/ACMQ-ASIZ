Installation of the djgpp versions of the ASIZ and EdFil programs.

Introduction:

- The X_ASIZ program analyses switched-current or switched-capacitor
  filters. It is faster and accepts larger circuits than the ASIZ
  program. (The present version is rather old. Other versions of the
  ASIZ program contains more functions, but this one works correctly too).

- The X_EdFil program is a schematic editor compatible with the EdFil
  program, but with a different interface, and capacity for larger
  circuits.

- The programs run normally under DOS or Windows.

- The djgpp package is a port of GNU C to the DOS environment,
  developed by DJ Delorie.
  It generates full 32-bit programs and supports full virtual memory
  with paging to disk. More informations and distribution files are
  available from http://www.delorie.com
  The programs were compiled with gcc 3.3.2

Installation:

- Put the executable programs in some directory included in the DOS path.
- Set the DOS environment variables (include in the autoexec.bat file):
  set TCBGI=<where is the LITT.CHR file>
    If not set, the text in the message windows will not look right.
    Not necessary it the file is in the current directory.
  set GRX20DRV=<parameters>
    where the parameters are:
    gw <width>     graphics width  (default is 640)
    gh <height>    graphics height (default is 480)
    nc <number of colors>  (default is 16)
  I recommend to set nc 256, as the 16 colors mode is too slow.
 - To run under DOS, a dpmi driver is necessary. The cwsdpmi extender
   can be obtained from the djgpp distribution. It is not necessary
   to run under Windows 95 or higher.
 - A mouse driver is recommended in a DOS only installation. The
   programs will provide an emulated mouse cursor controlled by the
   cursor keys if a mouse driver is not found.
   The buttons are substituted by:
   left:    Return
   central: Escape
   right:   Space
   The keys Home, PgDn, and PgUp change the cursor step.
   With CapsLock or Shift (in the Pascal version) active, the buttons work
   in toggle mode.
   ScrollLock suspends the emulation when active, allowing normal use of the
   keyboard.

For more informations, see the manual of the ASIZ program, in the main
distribution file at http://www.coe.ufrj/~acmq/ASIZ.html or contact the
author:

Dr. Antonio Carlos Moreirao de Queiroz
COPPE/UFRJ - Programa de Engenharia Eletrica
CP 68504
21945-970 Rio de Janeiro, RJ
Brazil

e-mail: acmq@ufrj.br

Last update: February 24 2004