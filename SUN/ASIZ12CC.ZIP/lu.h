#ifndef LU_H
#define LU_H

/*
*****************************************************************************
Resolve um sistema de equacoes complexo e o sistema adjunto, com matrizes
alocadas na "heap", usando fatoracao LU com condensacao pivotal.
Por: Antonio Carlos Moreirao de Queiroz - COPPE/DEEL/UFRJ 1993
V. 1.0 de 02/06/93 - Traducao para C
V. 1.0a de 02/01/95 - Mudados os nomes de deta e detb
V. 1.1  de 04/01/95 - Calculo acelerado evitando multiplicacoes por zero
*****************************************************************************
*/

/*
A implementar:
- Nao alocar lin/col 0, ao menos para fases
Obs: As solucoes para a equacao "0" nao estao sendo zeradas
*/

/* Definicoes de tipos uteis e funcoes */
#define boolean unsigned char
#define true 1
#define false 0

#define linmax          400
#define fasmax          16

typedef double rlinha[linmax+1];
typedef double *ptrlinha;

typedef double *rcoluna[linmax+1];
typedef double **ptrmatriz;

typedef short indice[linmax+1];

extern double Ires,deta,detb;   /*Determinante*/
extern double **Y1,**Y2,**E1,**E2,**A1,**A2; /*Matriz e excitacoes normal e adjunta*/

extern double Rmult(double x1,double x2,double y1,double y2);
extern double Rdiv(double x1,double x2,double y1,double y2);
extern boolean AlocarMatriz(double ***p,short linhas,short colunas);
extern void DesalocarMatriz(double ***p,short linhas,short colunas);
extern boolean AlocarSistema(short neq,short nfases);
extern void DesalocarSistema(void);
extern boolean ResolverSistema(short *Ax,double dmin);

#endif /*LU_H*/
